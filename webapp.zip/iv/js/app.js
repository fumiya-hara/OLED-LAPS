(function(APP, $, undefined) {
    
    // App configuration
    APP.config = {};
    APP.config.app_id = 'iv';
    APP.config.app_url = '/bazaar?start=' + APP.config.app_id + '?' + location.search.substr(1);
    APP.config.socket_url = 'ws://' + window.location.hostname + ':9002';

    // WebSocket
    APP.ws = null;

    // Plot
    APP.plot = {};

    // Signal stack
    APP.signalStack = [];

    // Parameters
    APP.processing = false;

    // Starts template application on server
    APP.startApp = function() {

        $.get(APP.config.app_url)
            .done(function(dresult) {
                if (dresult.status == 'OK') {
                    APP.connectWebSocket();
                } else if (dresult.status == 'ERROR') {
                    console.log(dresult.reason ? dresult.reason : "Could not start the application (ERR1)");
                    APP.startApp();
                } else {
                    console.log("Could not start the application (ERR2)");
                    APP.startApp();
                }
            })
            .fail(function() {
                console.log("Could not start the application (ERR3)");
                APP.startApp();
            });
    };




    APP.connectWebSocket = function() {

        //Create WebSocket
        if (window.WebSocket) {
            APP.ws = new WebSocket(APP.config.socket_url);
            APP.ws.binaryType = 'arraybuffer';
        } else if (window.MozWebSocket) {
            APP.ws = new MozWebSocket(APP.config.socket_url);
            APP.ws.binaryType = 'arraybuffer';
        } else {
            console.log("Browser does not support WebSocket");
        }


        // Define WebSocket event listeners
        if (APP.ws) {

            APP.ws.onopen = function() {
                $('#connect_message').text("Connected");
                console.log("Socket opened");

                APP.initParameter();
            };

            APP.ws.onclose = function() {
                $('#connect_message').text("Connection colsed");
                console.log("Socket closed");
            };

            APP.ws.onerror = function(ev) {
                $('#connect_message').text("Connection error");
                console.log("Websocket error: ", ev);
            };

            APP.ws.onmessage = function(ev) {
                //console.log("Message recieved");


                //Capture signals
                if (APP.processing) {
                    return;
                }
                APP.processing = true;

                try {
                    var data = new Uint8Array(ev.data);
                    var inflate = pako.inflate(data);
                    var text = String.fromCharCode.apply(null, new Uint8Array(inflate));
                    var receive = JSON.parse(text);

                    if (receive.parameters && Object.keys(receive.parameters).length) {
                        APP.onParameters(receive.parameters);
                    }

                    if (receive.signals) {
                        APP.signalStack.push(receive.signals);
                    }
                    APP.processing = false;
                } catch (e) {
                    APP.processing = false;
                    console.log(e);
                } finally {
                    APP.processing = false;
                }



            };
        }
    };

    APP.onParameters  = function(parameters) {
        //console.log(parameters);
        if (parameters.X_START && parameters.X_STEP) {
            APP.setXAxes(parameters.X_START.value, parameters.X_STEP.value)
        }
        $.each(parameters, function(name, parameter) {
            $('.rp-parameter[name="' + name + '"][readonly]').val(parameter.value);
        });
    }

    APP.sendParameter = function(parameters) {
        APP.ws.send(JSON.stringify({ parameters: parameters }));
    }

    APP.initParameter = function() {
        console.log($('.rp-parameter').serializeArray());
        var parameters = {};
        $('.rp-parameter').serializeArray().forEach(function(parameter) {
            if (parameter.value === 'on') {
                parameter.value = true;
            }
            parameters[parameter.name] = { value: parameter.value };
        });
        //console.log(parameters);
        APP.sendParameter(parameters);
    };

    APP.updateParameter= function(name, value) {
        var parameters = {};
        parameters[name] = { value: value };
        APP.sendParameter(parameters);
    };
    

    APP.x_start = 0;
    APP.x_step = 1;
    APP.setXAxes = function(start, step) {
        var axes = APP.plot.getAxes();
        var end = start + step * 1024;
        APP.x_step = step;
        APP.x_start = start;
        axes.xaxis.options.min = Math.min(start, end);
        axes.xaxis.options.max = Math.max(start, end);
        APP.plot.setupGrid();
        APP.plot.draw();
    }

    APP.updateLegend = function(x, values) {
        $('#value_x').text(parseFloat(x).toFixed(2));
        for(var i = 0; i < APP.signalInfo.length; i++) {
            $('.signal-value[signal_id="'+i+'"]').text(parseFloat(values[APP.signalInfo[i].name]).toFixed(2) + ' ' + APP.signalInfo[i].unit);
        }
    }

    APP.SIGNAL_TYPES = [
        {
            description: "",
            unit: "",
            scale: 1,
            offset: 0,
        },
        {
            description: "Amplitude",
            unit: "V",
            scale: 0.1,
            offset: -5,
        },
        {
            description: "Phase",
            unit: "deg",
            scale: 36,
            offset: 0,
        },
        {
            description: "Phase relative",
            unit: "deg",
            scale: 36,
            offset: 0,
        },
        {
            description: "Real",
            unit: "V",
            scale: 0.2,
            offset: 0,
        },
        {
            description: "Imag",
            unit: "V",
            scale: 0.2,
            offset: 0,
        },
        {
            description: "Mean",
            unit: "V",
            scale: 0.2,
            offset: 0,
        },
        {
            description: "Out of range",
            unit: "%",
            scale: 10,
            offset: -5,
        },
        {
            description: "RMS",
            unit: "V",
            scale: 0.1,
            offset: -5,
        },
    ];

    APP.signalInfo = [
        {
            name: 'SIGNAL_A',
            short: 'A',
            colorClass: "color_a",
            description: "",
            unit: "",
            channel: 1,
            scale: 1,
            offset: 0,
        },
        {
            name: 'SIGNAL_B',
            short: 'B',
            colorClass: "color_b",
            description: "",
            unit: "",
            channel: 1,
            scale: 1,
            offset: 0,
        },
        {
            name: 'SIGNAL_C',
            short: 'C',
            colorClass: "color_c",
            description: "",
            unit: "",
            channel: 1,
            scale: 1,
            offset: 0,
        },
    ];

    // Processes newly received data for signals
    APP.processSignals = function(new_signals) {

        APP.measurementData = [];
        var pointArr = [];
        var lastValue = {};
        var maxSize = 0;

        // Draw signals
        APP.signalInfo.forEach(function(sig) {
            var values = [];
            var points = [];
            if (new_signals[sig.name] && new_signals[sig.name].size > 0) {
                // Ignore empty signals
                for (var i = 0; i < new_signals[sig.name].size; i++) {
                    values.push([APP.x_start + APP.x_step * i, new_signals[sig.name].value[i]]);
                    points.push([APP.x_start + APP.x_step * i, new_signals[sig.name].value[i] / sig.scale + sig.offset]);
                }
                lastValue[sig.name] = new_signals[sig.name].value[new_signals[sig.name].size - 1];
                maxSize = Math.max(maxSize, new_signals[sig.name].size);
            }
            APP.measurementData.push(values);
            pointArr.push(points);
        });

        //Update value
        APP.updateLegend((APP.x_start + APP.x_step * (maxSize -1 )), lastValue);

        // Update graph
        APP.plot.setData(pointArr);
        APP.plot.resize();
        APP.plot.setupGrid();
        APP.plot.draw();
    };


    APP.measurementParameter = {};
    APP.measurementData = [];
    APP.exportToCSV = function(array) {
        function formatDate(date) {
            function pad(number) {
                if (number < 10) {
                    return '0' + number;
                }
                return number;
            }
            var txt = "" + date.getFullYear() + pad(date.getMonth()+1) + pad(date.getDate());
            txt += "_" + pad(date.getHours()) + pad(date.getMinutes()) + pad(date.getSeconds());
            return txt;
        }

        var signalNames = [];
        APP.signalInfo.forEach(function(sig) {
            signalNames.push(sig.description + '[' + sig.channel + ']' + '(' + sig.unit + ')');
        });

        APP.measurementParameter["Value"] = $('#measurment-info-value').val();
        APP.measurementParameter["Comment"] = $('#measurment-info-comment').val();

        var csvContent = "#Bias";
        for (var sig=0; sig < 3; sig++) {
            if (array[sig].length) {
                csvContent += '\t';
                csvContent += signalNames[sig];
            }
        }
        csvContent += '\r\n';
        for (var i=0; i < 1024; i++) {
            csvContent += (APP.x_start + APP.x_step * i);
            for (var sig=0; sig < 3; sig++) {
                if (array[sig].length) {
                    csvContent += '\t';
                    csvContent += array[sig][i][1];
                }
            }
            csvContent += '\r\n';
        }
        csvContent += '#';
        csvContent += JSON.stringify(APP.measurementParameter);
        csvContent += '\r\n';

        var data = new Blob([csvContent], {type: 'text/csv'});
        var textFile = window.URL.createObjectURL(data);
        var link = document.createElement('a');
        link.setAttribute('href', textFile);
        link.setAttribute('download', "iv-data_" + formatDate(APP.measurementParameter.Date) + ".csv");
        document.body.appendChild(link); // Required for FF
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(textFile);
    }

    //Handler
    APP.signalHandler = function() {
        if (APP.signalStack.length > 0) {
            APP.processSignals(APP.signalStack[0]);
            APP.signalStack.splice(0, 1);
        }
        if (APP.signalStack.length > 2) {
            console.log("Lost signal Stack");
            APP.signalStack = [];
        }
    }
    setInterval(APP.signalHandler, 15);


}(window.APP = window.APP || {}, jQuery));




// Page onload event handler
$(function() {
    //Init plot
    APP.plot = $.plot($('#plotwidget'), [], {
        series: {
            shadowSize: 0, // Drawing is faster without shadows
        },
        crosshair: {
	    mode: "x",
	},
        grid: {
	    hoverable: true,
            autoHighlight: false,
	},
        yaxis: {
            min: -5,
            max: 5,
            tickSize: 1,
        },
        xaxis: {
            min: 0,
            max: 1024,
        }
    });

    var updateLegendTimeout = null;
    var latestPosition = null;

    $("<div id='tooltip'></div>").css({
	position: "absolute",
	display: "none",
	border: "1px solid #fdd",
	padding: "2px",
	"background-color": "#fee",
	opacity: 0.80
    }).appendTo("body");

    function updateLegend() {
        function makeTooltip(x, divs, values) {
            var text = "" + x + ": ";
            var first = true;
            for (var i = 0; i < values.length; i++) {
                if (values[i] !== undefined) {
                    if (!first) {
                        text += ", ";
                    }
                    first = false;
                    text += '<br><span class="' + APP.signalInfo[i].colorClass + '">' + APP.signalInfo[i].short + "=" + divs[i] + "≘" + values[i] + ' ' + APP.signalInfo[i].unit + '</span>';
                }
            }
            return text;
        }
	updateLegendTimeout = null;
        var pos = latestPosition;

        var axes = APP.plot.getAxes();
	if (pos.x < axes.xaxis.min || pos.x > axes.xaxis.max ||
	    pos.y < axes.yaxis.min || pos.y > axes.yaxis.max) {
            $("#tooltip").hide();
            return;
        }

        var divs = [];
        var values = [];
        var x = parseFloat(pos.x).toFixed(2);

        var i, j, dataset = APP.plot.getData();
	for (var i = 0; i < dataset.length; i++) {
            var series = dataset[i];
            var j = Math.round((pos.x - APP.x_start) / APP.x_step);
            if (series.data.length <= j) {
                divs[i] = undefined;
                values[i] = undefined;
            } else {
                divs[i] = series.data[j][1].toFixed(2);
                values[i] = APP.measurementData[i][j][1].toFixed(2);
            }
	}
        $("#tooltip").html(makeTooltip(x, divs, values))
	    .css({top: pos.pageY+5, left: pos.pageX+5})
	    .fadeIn(200);
    }

    $("#plotwidget").bind("plothover", function (event, pos, item) {
        latestPosition = pos;
	if (!updateLegendTimeout) {
	    updateLegendTimeout = setTimeout(updateLegend, 20);
	}
    });

    // Button click func
    $('#read_button').click(function(event) {
        function parameterToObject() {
            //console.log($('.rp-parameter').serializeArray());
            var parameters = {};
            $('.rp-parameter').serializeArray().forEach(function(parameter) {
                if (parameter.value === 'on') {
                    parameter.value = true;
                }
                parameters[parameter.name] = parameter.value;
            });
            //console.log(parameters);
            return parameters;
        }
        event.preventDefault();

        APP.measurementParameter = parameterToObject();
        APP.measurementParameter["Date"] = new Date();
        APP.updateParameter(event.target.name, true);
    });

    $('#export').click(function(event) {
        event.preventDefault();
        APP.exportToCSV(APP.measurementData);
    });

    // Paramter input change event
    $('.rp-parameter').change(function(event) {
        //event.preventDefault();
        //console.log(event);
        //console.log(event.target.name);
        //console.log(event.target.type);
        //console.log(event.target.value);
        var value = event.target.value;
        if (event.target.type === 'checkbox') {
            value = event.target.checked;
        }
        //console.log(value);
        APP.updateParameter(event.target.name, value);
    });

    $('.signal-parameter-scale').change(function(event) {
        var sig_id = event.target.attributes.signal_id.value;
        APP.signalInfo[sig_id].scale = event.target.value;
    });

    $('.signal-parameter-offset').change(function(event) {
        var sig_id = event.target.attributes.signal_id.value;
        APP.signalInfo[sig_id].offset = event.target.value;
    });

    $('.signal-parameter-channel').change(function(event) {
        var sig_id = event.target.attributes.signal_id.value;
        APP.signalInfo[sig_id].channel = event.target.value;
    });

    $('.signal-parameter-channel').each(function(i, target) {
        var sig_id = target.attributes.signal_id.value;
        APP.signalInfo[sig_id].channel = target.value;
    });

    function updateSignalType(sig_id, type_id) {
        var sig_type = APP.SIGNAL_TYPES[type_id];
        APP.signalInfo[sig_id].description = sig_type.description;
        APP.signalInfo[sig_id].unit = sig_type.unit;
        APP.signalInfo[sig_id].scale = sig_type.scale;
        APP.signalInfo[sig_id].offset = sig_type.offset;
        $('.signal-parameter-scale[signal_id="'+sig_id+'"]').val(APP.signalInfo[sig_id].scale);
        $('.signal-parameter-offset[signal_id="'+sig_id+'"]').val(APP.signalInfo[sig_id].offset);
        $('.signal-unit[signal_id="'+sig_id+'"]').text(APP.signalInfo[sig_id].unit);
    }

    $('.signal-parameter-type').change(function(event) {
        var sig_id = event.target.attributes.signal_id.value;
        updateSignalType(sig_id, event.target.value);
    });

    $('.signal-parameter-type').each(function(i, target) {
        var sig_id = target.attributes.signal_id.value;
        updateSignalType(sig_id, target.value);
    });

    // Start application
    APP.startApp();
});
