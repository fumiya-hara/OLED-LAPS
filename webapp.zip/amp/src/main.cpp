#include <limits.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/sysinfo.h>
#include <sys/types.h>
#include <unistd.h>
#include <complex>
#include <vector>

#include "gen_stream.h"
#include "mixer.h"

#include "main.h"

// Signal size
#define SIGNAL_SIZE_DEFAULT (1024)
#define SIGNAL_NUM (3)
#define SIGNAL_UPDATE_INTERVAL 20

#define CHANNEL_NUM (2)
#define GENERATOR_NUM (2)

// Signal
CFloatSignal SIGNALS[SIGNAL_NUM] = {
    CFloatSignal("SIGNAL_A", SIGNAL_SIZE_DEFAULT, 0.0f),
    CFloatSignal("SIGNAL_B", SIGNAL_SIZE_DEFAULT, 0.0f),
    CFloatSignal("SIGNAL_C", SIGNAL_SIZE_DEFAULT, 0.0f)};

std::vector<std::complex<float>> g_complex[CHANNEL_NUM] = {
    std::vector<std::complex<float>>(SIGNAL_SIZE_DEFAULT),
    std::vector<std::complex<float>>(SIGNAL_SIZE_DEFAULT)};
std::vector<float> g_mean[CHANNEL_NUM] = {
    std::vector<float>(SIGNAL_SIZE_DEFAULT),
    std::vector<float>(SIGNAL_SIZE_DEFAULT)};
std::vector<float> g_oor[CHANNEL_NUM] = {
    std::vector<float>(SIGNAL_SIZE_DEFAULT),
    std::vector<float>(SIGNAL_SIZE_DEFAULT)};
std::vector<float> g_rms[CHANNEL_NUM] = {
    std::vector<float>(SIGNAL_SIZE_DEFAULT),
    std::vector<float>(SIGNAL_SIZE_DEFAULT)};

// Parameter
CFloatParameter GAIN[SIGNAL_NUM] = {
    CFloatParameter("GAIN_A", CBaseParameter::RW, 1, 0, 0.01, 100),
    CFloatParameter("GAIN_B", CBaseParameter::RW, 1, 0, 0.01, 100),
    CFloatParameter("GAIN_C", CBaseParameter::RW, 1, 0, 0.01, 100)};
CFloatParameter OFFSET[SIGNAL_NUM] = {
    CFloatParameter("OFFSET_A", CBaseParameter::RW, 0.0, 0, -50.0, 50.0),
    CFloatParameter("OFFSET_B", CBaseParameter::RW, 0.0, 0, -50.0, 50.0),
    CFloatParameter("OFFSET_C", CBaseParameter::RW, 0.0, 0, -50.0, 50.0)};
CIntParameter DATA[SIGNAL_NUM] = {
    CIntParameter("DATA_A", CBaseParameter::RW, 0, 0, 0, 8),
    CIntParameter("DATA_B", CBaseParameter::RW, 0, 0, 0, 8),
    CIntParameter("DATA_C", CBaseParameter::RW, 0, 0, 0, 8)};
CIntParameter CHANNEL[SIGNAL_NUM] = {
    CIntParameter("CHANNEL_A", CBaseParameter::RW, 1, 0, 0, 1),
    CIntParameter("CHANNEL_B", CBaseParameter::RW, 1, 0, 0, 1),
    CIntParameter("CHANNEL_C", CBaseParameter::RW, 1, 0, 0, 1)};

CBooleanParameter CHANNEL_GEN[GENERATOR_NUM] = {
    CBooleanParameter("CHANNEL_1", CBaseParameter::RW, false, 0),
    CBooleanParameter("CHANNEL_2", CBaseParameter::RW, false, 0)};
CFloatParameter BIAS[GENERATOR_NUM] = {
    CFloatParameter("BIAS_1", CBaseParameter::RW, 0.0, 0, -1, 1),
    CFloatParameter("BIAS_2", CBaseParameter::RW, 0.0, 0, -1, 1)};
CFloatParameter AMPLITUDE[GENERATOR_NUM] = {
    CFloatParameter("AMPLITUDE_1", CBaseParameter::RW, 0, 0, 0, 1),
    CFloatParameter("AMPLITUDE_2", CBaseParameter::RW, 0, 0, 0, 1)};
CFloatParameter PHASE[GENERATOR_NUM] = {
    CFloatParameter("PHASE_1", CBaseParameter::RW, 0, 0, -180, 180),
    CFloatParameter("PHASE_2", CBaseParameter::RW, 0, 0, -180, 180)};
CFloatParameter FREQUENCY[GENERATOR_NUM] = {
    CFloatParameter("FREQUENCY_1", CBaseParameter::RW, 0.01, 0, 0, 61035),
    CFloatParameter("FREQUENCY_2", CBaseParameter::RW, 0.01, 0, 0, 61035)};
CFloatParameter FREQUENCY_SET[GENERATOR_NUM] = {
    CFloatParameter("FREQUENCY_1_SET", CBaseParameter::RW, 0.01, 0, 0, 61035),
    CFloatParameter("FREQUENCY_2_SET", CBaseParameter::RW, 0.01, 0, 0, 61035)};
CIntParameter WFORM[GENERATOR_NUM] = {
    CIntParameter("WFORM_1", CBaseParameter::RW, 0, 0, 0, 1),
    CIntParameter("WFORM_2", CBaseParameter::RW, 0, 0, 0, 1)};

CFloatParameter BIAS_START("BIAS_START", CBaseParameter::RW, -2, 0, -2, 2);
CFloatParameter BIAS_END("BIAS_END", CBaseParameter::RW, 0, 0, -2, 2);
CFloatParameter BIAS_SLOPE("BIAS_SLOPE", CBaseParameter::RW, 100, 0, 0.4, 4000);
CFloatParameter BIAS_SLOPE_SET("BIAS_SLOPE_SET", CBaseParameter::RO, 100, 0,
                               0.4, 4000);
CFloatParameter BIAS_DELAY("BIAS_DELAY", CBaseParameter::RW, 300, 0, 0,
                           5000);  // ms
CFloatParameter BIAS_DELAY_SET("BIAS_DELAY_SET", CBaseParameter::RO, 300, 0, 0,
                               5000);  // ms
CIntParameter RAMP("RAMP", CBaseParameter::RW, 0, 0, 0, 1);
CFloatParameter RAMP_DURATION("RAMP_DURATION", CBaseParameter::RO, 0, 0, 0,
                              60 * 3);

CIntParameter PERIODS_READ("PERIODS_READ", CBaseParameter::RW, 1, 0, 1, 16384);
CFloatParameter FREQUENCY_READ("FREQUENCY_READ", CBaseParameter::RW, 0.01, 0,
                               0.001, 61035);
CFloatParameter FREQUENCY_READ_SET("FREQUENCY_READ_SET", CBaseParameter::RO,
                                   0.01, 0, 0.001, 61035);
CBooleanParameter READ_VALUE("READ_VALUE", CBaseParameter::RW, false, 0);

CFloatParameter X_START("X_START", CBaseParameter::RW, -2, 0, -2, 2);
CFloatParameter X_STEP("X_STEP", CBaseParameter::RW, 0.002, 0, -2, 2);

static const int32_t DECIMATION = 1024;

class Mixer {
 public:
  void updateParameter(const float frequency, const size_t periods = 1) {
    fprintf(stderr, "Mixer request: frequency %f Hz, periods to average %i\n",
            frequency, periods);
    period_length = mixer_frequency_to_length(frequency, decimation);
    setPeriodsToAverage(periods);
    periods_to_average = PERIODS_READ.Value();
  }
  void setPeriodsToAverage(const size_t periods) {
    periods_to_average = periods;
  }
  size_t getPeriodsToAverage() const { return periods_to_average; }
  float getFrequency() const {
    const float freq = mixer_frequency_by_length(period_length, decimation);
    fprintf(stderr,
            "Mixer result: period_length %u, periods_to_average %u, frequency "
            "%f Hz\n",
            period_length, periods_to_average, freq);
    return freq;
  }
  size_t getPeriodLength() const { return period_length; }
  size_t getLength() const { return period_length * periods_to_average; }
  void setup() {
    mixer_start(period_length * periods_to_average, period_length,
                rp_decimation, RP_TRIG_SRC_EXT_PE);
    while (!mixer_is_ready())
      ;
  }

 private:
  rp_acq_decimation_t rp_decimation = RP_DEC_1024;
  int32_t decimation = DECIMATION;
  size_t period_length = 1;
  size_t periods_to_average = 1;
};

static Mixer mixer;

class Modulation {
 public:
  enum waveform_t {
    WF_SINE = 0,
    WF_SQUARE = 1,
  };
  Modulation(const generate_channel_t channel) : channel(channel){};
  void updateParameter(const float frequency, const float phase,
                       const float amp, const float bias, const int wform) {
    fprintf(stderr,
            "Gen%i request: freq %f Hz, phase %f deg, amp %f V, offset %f deg, "
            "form %i\n",
            channel, frequency, phase, amp, bias, wform);
    length = mixer_frequency_to_length(frequency, decimation);
    delay = ((size_t)round((double)length * phase / 360.)) % length;
    amplitude = generate_voltage_to_int(amp);
    offset = generate_voltage_to_int(bias);
    form = (waveform_t)wform;
    cycles = 0;
  }
  void setCycles(const size_t cycles_) { cycles = cycles_; }
  float getFrequency() const {
    const float freq = mixer_frequency_by_length(length, decimation);
    fprintf(stderr,
            "Gen%i length %u, delay %u, amp %i, offset %i, freqenucy %f Hz\n",
            channel, length, delay, amplitude, offset, freq);
    return freq;
  }
  void resetParameter() {
    length = 0;
    delay = 0;
    amplitude = 0;
    offset = 0;
    form = WF_SINE;
    cycles = 0;
  }
  generate_channel_t getChannel() const { return channel; }
  bool isEnabled() const { return length > 0; }
  void setup() {
    if (isEnabled()) {
      int16_t data[length];
      if (form == WF_SQUARE) {
        // square
        synthesis_square(data, amplitude, offset, delay, length);
      } else {
        // sine
        synthesis_sin(data, amplitude, offset, delay, length);
      }
      generate_default_settings(channel);
      generate_setup_step(channel, generate_decimation_to_step(decimation));
      generate_setup_cycles(channel, cycles);
      generate_load_data(channel, data, length);
      generate_enable_output(channel);
      generate_setup_tigger(channel, GEN_TR_EXT_RISING);
    } else {
      generate_disable_output(channel);
    }
  }

 private:
  generate_channel_t channel;
  size_t length = 0;                // signal length
  int32_t decimation = DECIMATION;  // decimation
  size_t delay = 0;                 // phase shift in sample points
  int16_t amplitude = 0;
  int16_t offset = 0;
  waveform_t form = WF_SINE;
  size_t cycles = 0;
};

static Modulation generator[GENERATOR_NUM] = {Modulation(GEN_CH_A),
                                              Modulation(GEN_CH_B)};

class BiasRamp {
 public:
  // 2 min buffer: 2*60/(1/125e6*1024): about 56 MB
  // static const size_t RAMP_BUFFER_LENGTH = 14648438;
  // 3 min buffer: 2*60/(1/125e6*65536):
  static const size_t RAMP_BUFFER_LENGTH = 343323;
  static constexpr float BIAS_AMP_FACTOR = 2.0;
  BiasRamp(const generate_channel_t channel) : channel(channel){};
  void resetParameter() {
    periods_to_average = 0;
    ramp_length = 0;
    delay_length = 0;
    start = 0;
    end = 0;
    ignore_samples = 0;
    v_range = 0;
  }
  void updateParameter(const size_t period_length, const float bias_start,
                       const float bias_end, const float bias_slope,
                       const float delay_sec) {
    fprintf(
        stderr,
        "Bias ramp request: start %f V, end %f V, slope %f V/s, delay %f s\n",
        bias_start, bias_end, bias_slope, delay_sec);
    const uint32_t length_divider = decimation / DECIMATION;
    start = generate_voltage_to_int(bias_start / BIAS_AMP_FACTOR);
    end = generate_voltage_to_int(bias_end / BIAS_AMP_FACTOR);
    v_range = bias_end - bias_start;
    periods_to_average =
        std::max(abs(v_range) / bias_slope * GEN_ADC_RATE / DECIMATION /
                     period_length / SIGNAL_SIZE_DEFAULT,
                 1.0);
    ramp_length = period_length * SIGNAL_SIZE_DEFAULT * periods_to_average /
                  length_divider;
    ignore_samples =
        round(delay_sec * GEN_ADC_RATE / DECIMATION / period_length /
              periods_to_average / length_divider) *
        length_divider;
    delay_length =
        (ignore_samples * period_length * periods_to_average) / length_divider;
    fprintf(stderr,
            "Bias ramp result: start %i, end %i, ramp_length %u, "
            "ignore_samples %u, delay_length %u, periods_to_average %u\n",
            start, end, ramp_length, ignore_samples, delay_length,
            periods_to_average);
  }
  float getDuration() const {
    const float duration = ramp_length / GEN_ADC_RATE * decimation;
    fprintf(stderr, "Bias ramp result: duration %f s\n", duration);
    return duration;
  }
  float getDelaySec() const {
    const float delay_sec = delay_length / GEN_ADC_RATE * decimation;
    fprintf(stderr, "Bias ramp result: delay %f s\n", delay_sec);
    return delay_sec;
  }
  float getVoltageSlope() const {
    const float slope = abs(v_range) / getDuration();
    fprintf(stderr, "Bias ramp result: slope %f V/s\n", slope);
    return slope;
  }
  generate_channel_t getChannel() const { return channel; }
  size_t getPeriodsToAverage() const { return periods_to_average; }
  size_t getIgnoreSamples() const { return ignore_samples; }
  bool isEnabled() const { return ramp_length > 0; }
  void setup() {
    if (isEnabled()) {
      const size_t length = ramp_length + delay_length;
      if (length > RAMP_BUFFER_LENGTH) {
        fprintf(stderr, "WARNING: Ramp is too long!\n");
        return;
      }
      fill_ramp_buffer(delay_length, start);
      synthesis_ramp(ramp_buffer + delay_length, start, end, ramp_length);
      // synthesis_ramp_sin(ramp_buffer + delay_length, start, end, 512, 128,
      // ramp_length);
      generate_default_settings(channel);
      generate_enable_output(channel);
      generate_stream_start(channel, GEN_TR_EXT_RISING,
                            generate_decimation_to_step(decimation),
                            ramp_buffer, length, 1);
    }
  }
  void waitForReady() const {
    if (isEnabled()) {
      while (!generate_stream_is_ready(channel))
        ;
    }
  }

 private:
  generate_channel_t channel;
  int32_t decimation = 65536;
  size_t periods_to_average = 0;
  size_t ramp_length = 0;
  size_t delay_length = 0;
  int16_t start = 0;
  int16_t end = 0;
  size_t ignore_samples = 0;
  float v_range;
  int16_t ramp_buffer[RAMP_BUFFER_LENGTH];
  void fill_ramp_buffer(size_t length, int16_t value) {
    for (size_t i = 0; i < length; i++) {
      ramp_buffer[i] = value;
    }
  }
};

static BiasRamp biasRamp(GEN_CH_B);

static void setupGen() {
  for (unsigned int ch = 0; ch < GENERATOR_NUM; ch++) {
    if (generator[ch].getChannel() == biasRamp.getChannel() &&
        biasRamp.isEnabled()) {
      biasRamp.setup();
    } else {
      generator[ch].setup();
    }
  }
  biasRamp.waitForReady();
}

static void updatePlot() {
  const float x_start = BIAS_START.Value();
  const float x_step =
      (BIAS_END.Value() - BIAS_START.Value()) / SIGNAL_SIZE_DEFAULT;
  fprintf(stderr, "Plot: start %f V, step %f V\n", x_start, x_step);
  X_START.SendValue(x_start);
  X_STEP.SendValue(x_step);
}

static void fireTrigger() {
  fprintf(stderr, "Fire Trigger!\n");
  rp_DpinSetDirection(RP_DIO0_P, RP_OUT);
  rp_DpinSetState(RP_DIO0_P, RP_LOW);
  rp_DpinSetState(RP_DIO0_P, RP_HIGH);
  rp_DpinSetState(RP_DIO0_P, RP_HIGH);
  rp_DpinSetState(RP_DIO0_P, RP_LOW);
  rp_DpinSetDirection(RP_DIO0_P, RP_IN);
}

const char *rp_app_desc(void) {
  return (const char *)"Red Pitaya read voltage.\n";
}

int rp_app_init(void) {
  fprintf(stderr, "Loading read voltage application\n");

  // Initialization of API
  if (rpApp_Init() != RP_OK) {
    fprintf(stderr, "Red Pitaya API init failed!\n");
    return EXIT_FAILURE;
  } else
    fprintf(stderr, "Red Pitaya API init success!\n");

  // Set signal update interval
  // CDataManager::GetInstance()->SetSignalInterval(SIGNAL_UPDATE_INTERVAL);
  mixer_init();
  generate_init();

  return 0;
}

int rp_app_exit(void) {
  fprintf(stderr, "Unloading read voltage application\n");

  generate_release();
  mixer_release();
  rpApp_Release();

  return 0;
}

int rp_set_params(rp_app_params_t *p, int len) { return 0; }

int rp_get_params(rp_app_params_t **p) { return 0; }

int rp_get_signals(float ***s, int *sig_num, int *sig_len) { return 0; }

static size_t ignoreSamples = 0;
static size_t bufferPos = 0;
static size_t signalPos = 0;
static size_t pointsPerSample = 1;

void UpdateSignals(void) {
  while (mixer_pos_sub(mixer_write_pos(), bufferPos) > 0 &&
         signalPos < SIGNAL_SIZE_DEFAULT) {
    // fprintf(stderr, "UpdateSignals %i, %i, %i\n", dsBufferWritePos,
    // bufferPos, signalPos);
    for (unsigned int c = 0; c < CHANNEL_NUM; c++) {
      g_complex[c][signalPos] =
          std::complex<float>(mixer_buffer_I[c][bufferPos] / 8192.,
                              mixer_buffer_Q[c][bufferPos] / 8192.);
      g_mean[c][signalPos] = mixer_buffer_mean[c][bufferPos] / 8192.;
      g_oor[c][signalPos] =
          100. * mixer_buffer_oor[c][bufferPos] / pointsPerSample;
      g_rms[c][signalPos] = sqrt(mixer_buffer_square[c][bufferPos]) / 8192.;
      // fprintf(stderr, "UpdateSignals %f, %i, %i\n", (sqrt(val_I + val_Q)), i,
      // bufferPos);
    }
    bufferPos++;
    if (bufferPos >= MIXER_BUFFER_LENGTH) {
      bufferPos = 0;
    }
    // fprintf(stderr, "UpdateSignals updates %i\n", signalPos);
    if (ignoreSamples > 0) {
      ignoreSamples--;
      continue;
    }
    signalPos++;
    if (signalPos >= SIGNAL_SIZE_DEFAULT) {
      // fprintf(stderr, "UpdateSignals stop %i\n", signalPos);
      mixer_stop();
    }
  }

  // Write data to signal
  size_t signal_length = std::max(signalPos, 1U);
  for (unsigned int s = 0; s < SIGNAL_NUM; s++) {
    // fprintf(stderr, "UpdateSignals %u, s %u\n", signalPos, s);
    if (DATA[s].Value() > 0) {
      SIGNALS[s].Resize(signal_length);
    }
  }
  for (unsigned int i = 0; i < signal_length; i++) {
    for (unsigned int s = 0; s < SIGNAL_NUM; s++) {
      // fprintf(stderr, "UpdateSignals %u, i %u, s %u\n", signalPos, i, s);
      if (DATA[s].Value() == 1) {  // Amplitude
        SIGNALS[s][i] =
            abs(g_complex[CHANNEL[s].Value()][i]) * GAIN[s].Value() +
            OFFSET[s].Value();
      } else if (DATA[s].Value() == 2) {  // Phase
        SIGNALS[s][i] = arg(g_complex[CHANNEL[s].Value()][i]) * 180. / M_PI *
                            GAIN[s].Value() +
                        OFFSET[s].Value();
      } else if (DATA[s].Value() == 3) {  // Phase relative
        SIGNALS[s][i] = arg(g_complex[CHANNEL[s].Value()][i] /
                            g_complex[(CHANNEL[s].Value() + 1) % 2][i]) *
                            180. / M_PI * GAIN[s].Value() +
                        OFFSET[s].Value();
      } else if (DATA[s].Value() == 4) {  // Real
        SIGNALS[s][i] =
            real(g_complex[CHANNEL[s].Value()][i]) * GAIN[s].Value() +
            OFFSET[s].Value();
      } else if (DATA[s].Value() == 5) {  // Imag
        SIGNALS[s][i] =
            imag(g_complex[CHANNEL[s].Value()][i]) * GAIN[s].Value() +
            OFFSET[s].Value();
      } else if (DATA[s].Value() == 6) {  // Mean
        SIGNALS[s][i] =
            g_mean[CHANNEL[s].Value()][i] * GAIN[s].Value() + OFFSET[s].Value();
      } else if (DATA[s].Value() == 7) {  // Out of Range
        SIGNALS[s][i] =
            g_oor[CHANNEL[s].Value()][i] * GAIN[s].Value() + OFFSET[s].Value();
      } else if (DATA[s].Value() == 8) {  // RMS
        SIGNALS[s][i] =
            g_rms[CHANNEL[s].Value()][i] * GAIN[s].Value() + OFFSET[s].Value();
      }
    }
  }
}

void UpdateParams(void) {}

void OnNewParams(void) {
  for (unsigned int s = 0; s < SIGNAL_NUM; s++) {
    GAIN[s].Update();
    OFFSET[s].Update();
    DATA[s].Update();
    CHANNEL[s].Update();
    // fprintf(stderr, "Signal %i prarameter: gain %f, offset %f, data %i,
    // channel %i\n", s, GAIN[s].Value(), OFFSET[s].Value(), DATA[s].Value(),
    // CHANNEL[s].Value());
  }

  for (unsigned int i = 0; i < GENERATOR_NUM; i++) {
    CHANNEL_GEN[i].Update();
    BIAS[i].Update();
    AMPLITUDE[i].Update();
    FREQUENCY[i].Update();
    PHASE[i].Update();
    WFORM[i].Update();
    // fprintf(stderr, "Generator %i prarameter: enable %i, bias %f, amplitude
    // %f, freq %f, waveform %i\n", i, CHANNEL_GEN[i].Value(), BIAS[i].Value(),
    // AMPLITUDE[i].Value(), FREQUENCY[i].Value(), WFORM[i].Value());
  }

  BIAS_START.Update();
  BIAS_END.Update();
  BIAS_SLOPE.Update();
  BIAS_DELAY.Update();
  RAMP.Update();

  FREQUENCY_READ.Update();
  PERIODS_READ.Update();
  READ_VALUE.Update();

  mixer.updateParameter(FREQUENCY_READ.Value() * 1000, PERIODS_READ.Value());
  for (unsigned int ch = 0; ch < GENERATOR_NUM; ch++) {
    if (CHANNEL_GEN[ch].Value()) {
      generator[ch].updateParameter(FREQUENCY[ch].Value() * 1000,
                                    PHASE[ch].Value(), AMPLITUDE[ch].Value(),
                                    BIAS[ch].Value(), WFORM[ch].Value());
    } else {
      generator[ch].resetParameter();
    }
  }
  if (RAMP.Value() == 1) {
    biasRamp.updateParameter(mixer.getPeriodLength(), BIAS_START.Value(),
                             BIAS_END.Value(), BIAS_SLOPE.Value() / 1000,
                             BIAS_DELAY.Value() / 1000);
  } else {
    biasRamp.resetParameter();
  }
  if (biasRamp.isEnabled()) {
    mixer.setPeriodsToAverage(biasRamp.getPeriodsToAverage());
    PERIODS_READ.Set(biasRamp.getPeriodsToAverage());
    RAMP_DURATION.SendValue(biasRamp.getDuration());
    BIAS_DELAY_SET.SendValue(biasRamp.getDelaySec() * 1000);
    BIAS_SLOPE_SET.SendValue(biasRamp.getVoltageSlope() * 1000);
  }
  for (unsigned int ch = 0; ch < GENERATOR_NUM; ch++) {
    FREQUENCY_SET[ch].SendValue(generator[ch].getFrequency() / 1000);
  }
  FREQUENCY_READ_SET.SendValue(mixer.getFrequency() / 1000);

  if (READ_VALUE.Value() == true) {
    mixer_stop();
    signalPos = 0;
    bufferPos = 0;
    ignoreSamples = biasRamp.getIgnoreSamples();
    pointsPerSample = mixer.getLength();
    for (unsigned int i = 0; i < SIGNAL_SIZE_DEFAULT; i++) {
      for (unsigned int c = 0; c < CHANNEL_NUM; c++) {
        g_complex[c][i] = 0;
        g_mean[c][i] = 0;
        g_oor[c][i] = 0;
        g_rms[c][i] = 0;
      }
    }
    for (unsigned int ch = 0; ch < GENERATOR_NUM; ch++) {
      generator[ch].setCycles((ignoreSamples + SIGNAL_SIZE_DEFAULT) *
                              mixer.getPeriodsToAverage());
    }
    if (biasRamp.isEnabled()) {
      updatePlot();
    }
    mixer.setup();
    setupGen();
    fireTrigger();
    // Reset READ value
    READ_VALUE.Set(false);
  }
}

void OnNewSignals(void) {}

void PostUpdateSignals(void) {}
