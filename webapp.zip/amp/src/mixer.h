#ifndef MIXER_H
#define MIXER_H

#include <stdint.h>

#include "redpitaya/rp.h"

// RP_DEC_1024 (134ms), RP_DEC_64 (8ms), RP_DEC_8 (1ms), RP_DEC_1 (131 us)

const size_t MIXER_CHANNELS = 2;
const size_t MIXER_BUFFER_LENGTH = 1024;

extern int16_t mixer_buffer_mean[MIXER_CHANNELS][MIXER_BUFFER_LENGTH];
extern int32_t mixer_buffer_square[MIXER_CHANNELS][MIXER_BUFFER_LENGTH];
extern uint32_t mixer_buffer_oor[MIXER_CHANNELS][MIXER_BUFFER_LENGTH];
extern int16_t mixer_buffer_I[MIXER_CHANNELS][MIXER_BUFFER_LENGTH];
extern int16_t mixer_buffer_Q[MIXER_CHANNELS][MIXER_BUFFER_LENGTH];

// best results with num_samples multuple of period_legth and period_length
// multiple of 4
void mixer_start(const size_t num_samples, const size_t period_length,
                 rp_acq_decimation_t decimation = RP_DEC_1024,
                 rp_acq_trig_src_t trigger = RP_TRIG_SRC_NOW);
void mixer_stop();
bool mixer_is_ready();
size_t mixer_write_pos();
size_t mixer_pos_sub(const size_t a, const size_t b);
bool mixer_init();
void mixer_release();
// calculate length by frequency and decimation, rsult is multiple of 4
size_t mixer_frequency_to_length(const double frequency,
                                 const uint32_t decimation = 1024);
// calculate frequency by length and decimation
double mixer_frequency_by_length(const size_t length,
                                 const uint32_t decimation = 1024);

#endif
