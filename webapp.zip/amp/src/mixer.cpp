#include <math.h>
#include <pthread.h>
#include <stdio.h>
#include <chrono>
#include <thread>

#include "acq_stream.h"

#include "mixer.h"

const unsigned int MIXER_WORKER_PRIORITY = 60;

static const int16_t _OUT_OF_RANGE_BORDER = 8192 * 0.9;
static const uint16_t _LOT_AMPLITUDE_BIT = 13;

static bool _force_stop = false;
static bool _thread_running = false;
static bool _ready = false;
static bool _wait_for_trigger = false;
static std::thread _thread;

static size_t _buffer_write_pos = 0;
int16_t mixer_buffer_mean[MIXER_CHANNELS][MIXER_BUFFER_LENGTH] = {};
int32_t mixer_buffer_square[MIXER_CHANNELS][MIXER_BUFFER_LENGTH] = {};
uint32_t mixer_buffer_oor[MIXER_CHANNELS][MIXER_BUFFER_LENGTH] = {};
int16_t mixer_buffer_I[MIXER_CHANNELS][MIXER_BUFFER_LENGTH] = {};
int16_t mixer_buffer_Q[MIXER_CHANNELS][MIXER_BUFFER_LENGTH] = {};

static void _gen_lot(int16_t *data_out, const size_t length) {
  const float amp = 1 << _LOT_AMPLITUDE_BIT;
  for (size_t i = 0; i < length; i++) {
    data_out[i] = (amp * sin(2.0 * M_PI * (float)i / (float)length));
  }
}

static void _set_thread_pirority(std::thread &thread,
                                 const unsigned int priority) {
  sched_param sch;
  int policy;
  pthread_getschedparam(thread.native_handle(), &policy, &sch);
  sch.sched_priority = priority;
  if (pthread_setschedparam(thread.native_handle(), SCHED_FIFO, &sch)) {
    fprintf(stderr, "Failed to setschedparam.\n");
  }
}

static void _mixer_worker(const size_t num_samples,
                          const size_t period_length) {
  fprintf(stderr, "_mixer_worker start: num_samples %u, period_length %u\n",
          num_samples, period_length);
  size_t src_read_pos = acquire_write_pos();
  size_t target_write_pos = 0;
  size_t lot_cosine_pos = period_length / 4;
  size_t lot_sine_pos = 0;
  size_t curr_sample = 0;
  const volatile int32_t *src_buff[MIXER_CHANNELS] = {
      acquire_get_ch_buffer(ACQ_CH_A), acquire_get_ch_buffer(ACQ_CH_B)};

  int64_t val_mean[MIXER_CHANNELS] = {};
  int64_t val_square[MIXER_CHANNELS] = {};
  uint32_t val_oor[MIXER_CHANNELS] = {};
  int64_t val_I[MIXER_CHANNELS] = {};
  int64_t val_Q[MIXER_CHANNELS] = {};

  int16_t lot[period_length];
  _gen_lot(lot, period_length);

  _set_thread_pirority(_thread, MIXER_WORKER_PRIORITY);
  // indicate we are ready
  _ready = true;
  // wait for trigge if requiered
  if (_wait_for_trigger) {
    fprintf(stderr, "_mixer_worker wait for trigger\n");
    rp_acq_trig_state_t trigger_state = RP_TRIG_STATE_WAITING;
    while ((trigger_state == RP_TRIG_STATE_WAITING) && !_force_stop) {
      rp_AcqGetTriggerState(&trigger_state);
      std::this_thread::sleep_for(std::chrono::microseconds(50));
    }
    src_read_pos = acquire_trigger_pos();
    fprintf(stderr, "_mixer_worker: trigger at %u\n", src_read_pos);
  }
  fprintf(stderr, "_mixer_worker enter loop\n");
  while (!_force_stop) {
    // number of samples ready to read
    size_t diff = acquire_pos_sub(acquire_write_pos(), src_read_pos);
    // fprintf(stderr, "_mixer_worker: diff=%u\n", diff);
    if (diff == 0) {
      // wait on idle
      // fprintf(stderr, "_mixer_worker: sleep, src_read_pos %u\n",
      // src_read_pos);
      std::this_thread::sleep_for(std::chrono::microseconds(50));
      continue;
    }
    if (diff >= ACQ_BUFFER_LENGTH / 2) {
      fprintf(stderr, "_mixer_worker: WARNING diff=%u\n", diff);
    }
    while (diff > 0) {
      for (size_t ch = 0; ch < MIXER_CHANNELS; ch++) {
        int32_t value = acquire_to_int16(src_buff[ch][src_read_pos]);
        val_mean[ch] += value;
        val_square[ch] += value * value;
        val_oor[ch] += abs(value) > _OUT_OF_RANGE_BORDER;
        val_I[ch] += value * lot[lot_cosine_pos];  // cosine, real
        val_Q[ch] += value * lot[lot_sine_pos];    // sine, imag
      }
      curr_sample++;
      if (curr_sample >= num_samples) {
        for (size_t ch = 0; ch < MIXER_CHANNELS; ch++) {
          int64_t n = num_samples;
          mixer_buffer_mean[ch][target_write_pos] = val_mean[ch] / n;
          mixer_buffer_square[ch][target_write_pos] = val_square[ch] / n;
          mixer_buffer_oor[ch][target_write_pos] = val_oor[ch];
          mixer_buffer_I[ch][target_write_pos] =
              (val_I[ch] >> (_LOT_AMPLITUDE_BIT - 1)) / n;
          mixer_buffer_Q[ch][target_write_pos] =
              (val_Q[ch] >> (_LOT_AMPLITUDE_BIT - 1)) / n;
          val_mean[ch] = 0;
          val_square[ch] = 0;
          val_oor[ch] = 0;
          val_I[ch] = 0;
          val_Q[ch] = 0;
        }
        curr_sample = 0;
        target_write_pos++;
        if (target_write_pos >= MIXER_BUFFER_LENGTH) {
          target_write_pos = 0;
        }
        // publish target write pointer
        _buffer_write_pos = target_write_pos;
      }
      src_read_pos++;
      if (src_read_pos >= ACQ_BUFFER_LENGTH) {
        src_read_pos = 0;
      }
      lot_sine_pos++;
      if (lot_sine_pos >= period_length) {
        lot_sine_pos = 0;
      }
      lot_cosine_pos++;
      if (lot_cosine_pos >= period_length) {
        lot_cosine_pos = 0;
      }
      diff--;
    }
  }
  rp_AcqStop();
  fprintf(stderr, "_mixer_worker stop\n");
}

void mixer_start(const size_t num_samples, const size_t period_length,
                 rp_acq_decimation_t decimation, rp_acq_trig_src_t trigger) {
  mixer_stop();
  _force_stop = false;
  _ready = false;
  _buffer_write_pos = 0;
  _wait_for_trigger = true;
  if (trigger == RP_TRIG_SRC_DISABLED || trigger == RP_TRIG_SRC_NOW) {
    _wait_for_trigger = false;
  }
  rp_AcqReset();
  rp_AcqSetDecimation(decimation);
  rp_AcqSetTriggerDelay(8 * 1024);
  rp_AcqSetTriggerSrc(trigger);
  rp_AcqStart();
  _thread = std::thread(_mixer_worker, num_samples, period_length);
  _thread_running = true;
}

void mixer_stop() {
  if (!_thread_running) return;
  _force_stop = true;
  _thread.join();
  _thread_running = false;
}

bool mixer_is_ready() { return _ready; }

size_t mixer_write_pos() { return _buffer_write_pos; }

size_t mixer_pos_sub(const size_t a, const size_t b) {
  return (a - b) % MIXER_BUFFER_LENGTH;
}

bool mixer_init() {
  if (rp_Init() != RP_OK) {
    return false;
  }
  if (!acquire_init()) {
    return false;
  }
  return true;
}

void mixer_release() {
  mixer_stop();
  acquire_release();
  rp_Release();
}

size_t mixer_frequency_to_length(const double frequency,
                                 const uint32_t decimation) {
  return round(ACQ_DAC_RATE / decimation / frequency / 4) * 4;
}

double mixer_frequency_by_length(const size_t length,
                                 const uint32_t decimation) {
  return ACQ_DAC_RATE / decimation / length;
}
