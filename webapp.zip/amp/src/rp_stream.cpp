#include <fcntl.h>
#include <unistd.h> 
#include <sys/mman.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <math.h>
#include "rp_stream.h"

#include <chrono>
#include <thread>
#include <pthread.h>


static int fd_api;

int cmn_init() {
  if (!fd_api) {
    if((fd_api = open("/dev/mem", O_RDWR | O_SYNC)) == -1) {
    //if((fd_api = open("/dev/uio/api", O_RDWR | O_SYNC)) == -1) {
      return RP_EOMD;
    }
  }
  return RP_OK;
}

int cmn_release() {
  if (fd_api) {
    if(close(fd_api) < 0) {
      return RP_ECMD;
    }
  }
  return RP_OK;
}

int cmn_map(size_t size, size_t offset, void** mapped) {
  if(fd_api == -1) {
    return RP_EMMD;
  }

  //offset = (offset >> 20) * sysconf(_SC_PAGESIZE);
  
  *mapped = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd_api, offset);
  if(mapped == (void *) -1) {
    return RP_EMMD;
  }
  return RP_OK;
}

int cmn_unmap(size_t size, void** mapped) {
  if(fd_api == -1) {
    return RP_EUMD;
  }
  if((mapped == (void *) -1) || (mapped == NULL)) {
    return RP_EUMD;
  }
  if((*mapped == (void *) -1) || (*mapped == NULL)) {
    return RP_EUMD;
  }
  if(munmap(*mapped, size) < 0){
    return RP_EUMD;
  }
  *mapped = NULL;
  return RP_OK;
}


// Base Oscilloscope address
static const size_t OSC_BASE_ADDR = 0x40100000UL;
static const size_t OSC_BASE_SIZE = 0x00030000UL;
//static const int OSC_BASE_ADDR = 0x00100000;
//static const int OSC_BASE_SIZE = 0x30000;
static const size_t OSC_RAM_A_ADDR = OSC_BASE_ADDR + 0x10000;
static const size_t OSC_RAM_B_ADDR = OSC_BASE_ADDR + 0x20000;
const size_t OSC_RAM_A_SIZE = 0xFFFC;
const size_t OSC_RAM_B_SIZE = 0xFFFC;

// Oscilloscope structure declaration
typedef struct osc_control_s {
  struct {
    uint32_t arm : 1;
    uint32_t reset : 1;
    uint32_t trigger_status : 1;
  } conf;
  uint32_t trig_source;
  uint32_t cha_thr;
  uint32_t chb_thr;
  uint32_t trigger_delay;
  uint32_t data_dec;
  uint32_t wr_ptr_cur;
  uint32_t wr_ptr_trigger;
  uint32_t cha_hystersis;
  uint32_t chb_hystersis;
  uint32_t other;
  uint32_t pre_trigger_counter;
  uint32_t cha_filt_aa;
  uint32_t cha_filt_bb;
  uint32_t cha_filt_kk;
  uint32_t cha_filt_pp;
  uint32_t chb_filt_aa;
  uint32_t chb_filt_bb;
  uint32_t chb_filt_kk;
  uint32_t chb_filt_pp;
  uint32_t cha_aix_low_addr;
  uint32_t cha_aix_upper_addr;
  uint32_t cha_aix_samples;
  uint32_t cha_aix_enable;
  uint32_t cha_aix_wr_ptr_trigger;
  uint32_t cha_aix_wr_ptr_cur;
  uint32_t _res1;
  uint32_t _res2;
  uint32_t chb_aix_low_addr;
  uint32_t chb_aix_upper_addr;
  uint32_t chb_aix_samples;
  uint32_t chb_aix_enable;
  uint32_t chb_aix_wr_ptr_trigger;
  uint32_t chb_aix_wr_ptr_cur;
  uint32_t _res3;
  uint32_t _res4;  
  uint32_t trig_dbc_t;
} osc_control_t;


static volatile osc_control_t *osc_reg = NULL;
volatile int32_t *osc_buf_a = NULL;
volatile int32_t *osc_buf_b = NULL;


#define ACQUISITION_LENGTH      200000          /* samples */
#define PRE_TRIGGER_LENGTH 40000 /* samples */
static volatile void *scope;    /* access to fpga registers must not be optimized */
static void *buf_a = MAP_FAILED;
static void *buf_b = MAP_FAILED;



int mem_fd;
void *smap = MAP_FAILED;
int osc_init() {
  cmn_map(OSC_BASE_SIZE, OSC_BASE_ADDR, (void**)&osc_reg);
  //cmn_map(OSC_RAM_A_SIZE, OSC_RAM_A_ADDR, (void**)&osc_buf_a);
  //cmn_map(OSC_RAM_B_SIZE, OSC_RAM_B_ADDR, (void**)&osc_buf_b);

  mem_fd = open("/dev/mem", O_RDWR);
  //mem_fd = fd;
  smap = mmap(NULL, 0x00100000UL, PROT_WRITE | PROT_READ, MAP_SHARED, mem_fd, 0x40100000UL);
  buf_a = mmap(NULL, OSC_RAM_A_SIZE, PROT_READ, MAP_SHARED, mem_fd, OSC_RAM_A_ADDR);
  buf_b = mmap(NULL, OSC_RAM_B_SIZE, PROT_READ, MAP_SHARED, mem_fd, OSC_RAM_B_ADDR);
  osc_buf_a = (volatile int32_t *)buf_a;
  osc_buf_b = (volatile int32_t *)buf_b;
  scope = smap;

  return RP_OK;
}

int osc_release() {
  cmn_unmap(OSC_BASE_SIZE, (void**)&osc_reg);
  
  munmap(smap, 0x00100000UL);
  munmap(buf_a, OSC_RAM_A_SIZE);
  munmap(buf_b, OSC_RAM_B_SIZE);
  close(mem_fd);
  return RP_OK;
}

void osc_reset() {
  //osc_reg->conf.reset = 1;
  *(uint32_t *)(osc_reg) = 2; /* reset scope */
}

static void osc_set_filters(enum equalizer eq, int shaping, int channel) {
  uint32_t aa = 0;
  uint32_t bb = 0;
  uint32_t kk = 0;
  uint32_t pp = 0;
  // equalization filter
  switch (eq) {
  case EQ_HV:
    aa = 0x4c5f;
    bb = 0x2f38b;
    break;
  case EQ_LV:
    aa = 0x7d93;
    bb = 0x437c7;
    break;
  case EQ_OFF:
    aa = 0x0;
    bb = 0x0;
    break;
  }
  // shaping filter
  if (shaping) {
    kk = 0xd9999a;
    pp = 0x2666;
  } else {
    kk = 0xffffff;
    pp = 0x0;
  }
  if (channel == 0) {
    osc_reg->cha_filt_aa = aa;
    osc_reg->cha_filt_bb = bb;
    osc_reg->cha_filt_kk = kk;
    osc_reg->cha_filt_pp = pp;
  } else {
    osc_reg->chb_filt_aa = aa;
    osc_reg->chb_filt_bb = bb;
    osc_reg->chb_filt_kk = kk;
    osc_reg->chb_filt_pp = pp;
  }    
}

void osc_setup_input_parameters(enum decimation dec, enum equalizer ch_a_eq, enum equalizer ch_b_eq, int ch_a_shaping, int ch_b_shaping) {
  osc_reg->data_dec = dec;  // decimation
  osc_reg->other = (dec != DE_OFF) ? 1 : 0;  // enable averaging
  osc_set_filters(ch_a_eq, ch_a_shaping, 0); // filter coeff base channel a
  osc_set_filters(ch_b_eq, ch_b_shaping, 1); // filter coeff base channel b
}

void osc_setup_trigger_parameters(int thresh_a, int thresh_b, int hyst_a, int hyst_b, int deadtime) {
  osc_reg->cha_thr = thresh_a;
  osc_reg->chb_thr = thresh_b;
  /* the legacy recording logic controls when the trigger mode will be reset. we want
   * that to happen as soon as possible (because that's the signal that a trigger event
   * occured, and the pre-trigger samples are already waiting for transmission), so set
   * some small value > 0 here */
  osc_reg->trigger_delay = 10; // legacy post trigger samples
  osc_reg->cha_hystersis = hyst_a;
  osc_reg->chb_hystersis = hyst_b;
  osc_reg->trig_dbc_t = deadtime;
}

void osc_activate_trigger(enum trigger trigger) {
  *(uint32_t *)(osc_reg) = 2; /* reset scope */
  /*
  osc_reg->conf.reset = 1; // reset and arm scope
  osc_reg->conf.arm = 1;
  osc_reg->conf.arm = 0; // armed for trigger
  */
  *(uint32_t *)(osc_reg) = 3; // reset and arm scope
  *(uint32_t *)(osc_reg) = 0; // armed for trigger
  osc_reg->trig_source = trigger; 
}

unsigned int osc_write_pos() {
  return osc_reg->wr_ptr_cur;
  //unsigned int curr_pos = *(uint32_t *)(scope + 0x00018);
  //return curr_pos;
}

unsigned int osc_trigger_pos() {
  return osc_reg->wr_ptr_trigger;
  //unsigned int start_pos = *(uint32_t *)(scope + 0x0001C);
  //return start_pos;
}

unsigned int osc_pos_add(unsigned int a, unsigned int b) {
  return (a + b) % (OSC_RAM_A_SIZE/sizeof(int32_t));
}

unsigned int osc_pos_sub(unsigned int a, unsigned int b) {
  return (a - b) % (OSC_RAM_B_SIZE/sizeof(int32_t));
}





int osc_info() {
  fprintf(stderr, "conf arm %u, reset %u, tigger_status %u\n", osc_reg->conf.arm, osc_reg->conf.reset, osc_reg->conf.trigger_status);
  //printf("conf %u\n",  osc_reg->conf);
  fprintf(stderr, "source %u\n",  osc_reg->trig_source);
  fprintf(stderr, "ch a curPos %u, triggerPointer %u\n", osc_write_pos(), osc_trigger_pos());
  return RP_OK;
}



// Base Generate address
#define GENERATE_BASE_ADDR 0x40200000
#define GENERATE_BASE_SIZE 0x00030000
#define GENERATE_CHA_DATA_OFFSET 0x10000
#define GENERATE_CHB_DATA_OFFSET 0x20000

typedef struct ch_properties {
    unsigned int amplitudeScale     :14;
    unsigned int                    :2;
    unsigned int amplitudeOffset    :14;
    unsigned int                    :2;
    uint32_t counterWrap;
    uint32_t startOffset;
    uint32_t counterStep;
    unsigned int                    :2;
    uint32_t buffReadPointer        :14;
    unsigned int                    :16;
    uint32_t cyclesInOneBurst;
    uint32_t burstRepetitions;
    uint32_t delayBetweenBurstRepetitions;
} ch_properties_t;

typedef struct generate_control_s {
    unsigned int AtriggerSelector   :4;
    unsigned int ASM_WrapPointer    :1;
    unsigned int                    :1;
    unsigned int ASM_reset          :1;
    unsigned int AsetOutputTo0      :1;
    unsigned int AgatedBursts       :1;
    unsigned int                    :7;

    unsigned int BtriggerSelector   :4;
    unsigned int BSM_WrapPointer    :1;
    unsigned int                    :1;
    unsigned int BSM_reset          :1;
    unsigned int BsetOutputTo0      :1;
    unsigned int BgatedBursts       :1;
    unsigned int                    :7;

    ch_properties_t properties_chA;
    ch_properties_t properties_chB;
} generate_control_t;


static volatile generate_control_t *generate = NULL;
static volatile int32_t *generate_data_chA = NULL;
static volatile int32_t *generate_data_chB = NULL;

struct generate_worker_param {
  bool force_stop = false;
  bool running = false;
  bool ready = false;
  std::thread thread;
  unsigned int channel = 0;
  generate_trigger trigger;
  uint32_t step;
  const int16_t * data;
  size_t length;
  size_t cycles;
};

static generate_worker_param worker_cha;
static generate_worker_param worker_chb;

static void generate_init_worker(generate_worker_param &param) {
  param.trigger = G_TR_NOW;
  param.step = 0;
  param.cycles = 0;
  param.data = NULL;
  param.length = 0;
  param.force_stop = false;
  param.running = false;
  param.ready = false;
  param.ready = true;
}

int generate_init() {
  cmn_map(GENERATE_BASE_SIZE, GENERATE_BASE_ADDR, (void **) &generate);
  generate_data_chA = (int32_t *) ((char *) generate + (GENERATE_CHA_DATA_OFFSET));
  generate_data_chB = (int32_t *) ((char *) generate + (GENERATE_CHB_DATA_OFFSET));
  generate_init_worker(worker_cha);
  worker_cha.channel = 0;
  generate_init_worker(worker_chb);
  worker_chb.channel = 1;
  return RP_OK;
}

int generate_release() {
  cmn_unmap(GENERATE_BASE_SIZE, (void **) &generate);
  generate_data_chA = NULL;
  generate_data_chB = NULL;
  return RP_OK;
}


void generate_default_settings() {
  // no burst
  generate->properties_chA.cyclesInOneBurst = 0; // Number of repeats of table readout. 0=infinite
  generate->properties_chA.burstRepetitions = 0;
  generate->properties_chA.delayBetweenBurstRepetitions = 0;
  generate->properties_chB.cyclesInOneBurst = 0; // Number of repeats of table readout. 0=infinite
  generate->properties_chB.burstRepetitions = 0;
  generate->properties_chB.delayBetweenBurstRepetitions = 0;
  // full_scale
  generate->properties_chA.amplitudeScale = 0x2000;
  generate->properties_chA.amplitudeOffset = 0;
  generate->properties_chB.amplitudeScale = 0x2000;
  generate->properties_chB.amplitudeOffset = 0;
  // whole buffer
  generate->properties_chA.counterWrap = 65536 * GENERATE_BUFFER_LENGTH - 1;
  generate->properties_chA.startOffset = 0;
  generate->properties_chB.counterWrap = 65536 * GENERATE_BUFFER_LENGTH - 1;
  generate->properties_chB.startOffset = 0;
}

static void generate_cha_cycles(uint32_t cylcles) {
  generate->properties_chA.cyclesInOneBurst = cylcles;
}

static void generate_chb_cycles(uint32_t cylcles) {
  generate->properties_chB.cyclesInOneBurst = cylcles;
}

static void generate_cha_wrap(uint32_t length) {
  generate->properties_chA.counterWrap = 65536 * length - 1;
}

static void generate_chb_wrap(uint32_t length) {
  generate->properties_chB.counterWrap = 65536 * length - 1;
}

void generate_cha_zero() {
  generate->AsetOutputTo0 = 1;
}

void generate_chb_zero() {
  generate->BsetOutputTo0 = 1;
}

static void generate_cha_stop() {
  generate->ASM_reset = 1;
}

static void generate_chb_stop() {
  generate->BSM_reset = 1;
}

void generate_cha_setup_tigger(const generate_trigger trigger) {
    generate->ASM_reset = 1;
    generate->AtriggerSelector = trigger;
    generate->ASM_WrapPointer = 1; //?? rp api set 1 in setFreq
    generate->AsetOutputTo0 = 0;
    generate->AgatedBursts = 0;
    generate->ASM_reset = 0;
}

void generate_chb_setup_tigger(const generate_trigger trigger) {
    generate->BSM_reset = 1;
    generate->BtriggerSelector = trigger;
    generate->BSM_WrapPointer = 1; //??
    generate->BsetOutputTo0 = 0;
    generate->BgatedBursts = 0;  
    generate->BSM_reset = 0;
}

void generate_cha_step(const uint32_t step) {
  //fprintf(stderr, "step old: %u new %u\n",  generate->properties_chA.counterStep, step);
  generate->properties_chA.counterStep = step;
}

void generate_chb_step(const uint32_t step) {
  generate->properties_chB.counterStep = step;
}

unsigned int generate_a_read_pos() {
  return generate->properties_chA.buffReadPointer;
}

unsigned int generate_b_read_pos() {
  return generate->properties_chB.buffReadPointer;
}

unsigned int generate_pos_add(const unsigned int a, const unsigned int b) {
  return (a + b) % GENERATE_BUFFER_LENGTH;
}

unsigned int generate_pos_sub(const unsigned int a, const unsigned int b) {
  return (a - b) % GENERATE_BUFFER_LENGTH;
}

static void generate_copy_to_buff(volatile int32_t *target, const unsigned int start, const int16_t *src, const size_t length) {
  //fprintf(stderr, "generate_copy_to_buff start %u, length %u\n", start, length);
  uint32_t write_pos = start;
  for(uint32_t i = 0; i < length; i++) {
    target[write_pos] = src[i];
    write_pos++;
    if (write_pos > GENERATE_BUFFER_LENGTH) {
      write_pos = 0;
    }
  }
}

static void generate_fill_buff(volatile int32_t *target, const unsigned int start, const int16_t value, const size_t length) {
  uint32_t write_pos = start;
  for(uint32_t i = 0; i < length; i++) {
    target[write_pos] = value;
    write_pos++;
    if (write_pos > GENERATE_BUFFER_LENGTH) {
      write_pos = 0;
    }
  }
}

void synthesis_sin(int16_t *data_out, const int32_t amplitude, const int32_t offset, const uint32_t delay, const size_t length) {
  for(int unsigned i = 0; i < length; i++) {
    data_out[i] = (int32_t)(amplitude * sin(2.0 * M_PI * (float)i / (float)length + (float)delay)) + offset;
  }
}

void synthesis_square(int16_t *data_out, const int32_t amplitude, const int32_t offset, const uint32_t delay, const size_t length) {
    // Various locally used constants - HW specific parameters
    const int trans = 30;
    //const int trans = 300;

    for(int unsigned i = 0; i < length; i++) {
      unsigned int j = (i + delay) % length;
      if((0 <= i) &&
         (i <  length/2 - trans)) {
        data_out[j] = offset + amplitude;
      } else if ((i >= length/2 - trans) &&
                 (i <  length/2)) {
        data_out[j] = offset + amplitude - (2 * amplitude / trans) * (i - (length/2 - trans));
      } else if ((0 <= length/2) &&
                 (i <  length - trans)) {
        data_out[j] = offset - amplitude;
      } else if ((i >= length - trans) &&
                 (i <  length)) {
        data_out[j] = offset - amplitude + (2 * amplitude / trans) * (i - (length - trans));
      }
    }
}

void synthesis_ramp(int16_t *data_out, const int32_t start, const int32_t end, const size_t length) {
  for(int unsigned i = 0; i < length; i++) {
    data_out[i] = i*(end-start)/length + start;
  }
}

void synthesis_ramp_sin(int16_t *data_out, const int32_t amplitude, const int32_t start, const int32_t end, const uint32_t periods, const size_t length) {
  for(int unsigned i = 0; i < length; i++) {
    data_out[i] = (int32_t)(amplitude * sin(2.0 * M_PI * (float)i / (float)length * (float)periods))
      + i*(end-start)/length + start;
  }
}


void generate_cont_cha(const generate_trigger trigger, const uint32_t step, const int16_t *src, const size_t length) {
  if (length > GENERATE_BUFFER_LENGTH) {
    fprintf(stderr, "stream data too long!\n");
    return;
  }
  generate_cha_step(step);
  generate_copy_to_buff(generate_data_chA, 0, src, length);
  generate_cha_wrap(length);
  generate_cha_setup_tigger(trigger);
}

void generate_cha_info() {
  printf("AtriggerSelector %u, ASM_WrapPointer %u, ASM_reset %u, AsetOutputTo0 %u, AgatedBursts %u\n",
         generate->AtriggerSelector,
         generate->ASM_WrapPointer,
         generate->ASM_reset,
         generate->AsetOutputTo0,
         generate->AgatedBursts);
  printf("CH A: amplitudeScale %u, amplitudeOffset %u, counterWrap %u, startOffset %u, counterStep %u,\n      buffReadPointer %u, cyclesInOneBurst %u, burstRepetitions %u, delayBetweenBurstRepetitions %u\n",
         generate->properties_chA.amplitudeScale,
         generate->properties_chA.amplitudeOffset,
         generate->properties_chA.counterWrap,
         generate->properties_chA.startOffset,
         generate->properties_chA.counterStep,
         generate->properties_chA.buffReadPointer,
         generate->properties_chA.cyclesInOneBurst,
         generate->properties_chA.burstRepetitions,
         generate->properties_chA.delayBetweenBurstRepetitions);
}

void generate_chb_info() {
  printf("BtriggerSelector %u, BSM_WrapPointer %u, BSM_reset %u, BsetOutputTo0 %u, BgatedBursts %u\n",
         generate->BtriggerSelector,
         generate->BSM_WrapPointer,
         generate->BSM_reset,
         generate->BsetOutputTo0,
         generate->BgatedBursts);
  printf("CH B: amplitudeScale %u, amplitudeOffset %u, counterWrap %u, startOffset %u, counterStep %u,\n      buffReadPointer %u, cyclesInOneBurst %u, burstRepetitions %u, delayBetweenBurstRepetitions %u\n",
         generate->properties_chB.amplitudeScale,
         generate->properties_chB.amplitudeOffset,
         generate->properties_chB.counterWrap,
         generate->properties_chB.startOffset,
         generate->properties_chB.counterStep,
         generate->properties_chB.buffReadPointer,
         generate->properties_chB.cyclesInOneBurst,
         generate->properties_chB.burstRepetitions,
         generate->properties_chB.delayBetweenBurstRepetitions);
}



/*
  https://github.com/RedPitaya/RedPitaya/blob/master/fpga/regset.rst
  https://github.com/HrRossi/RedPitaya/blob/dev_axi_adc_example/Examples/C/axi_adc.c
*/


static void setThreadPirority(std::thread &thread, const unsigned int priority) {
  sched_param sch;
  int policy;
  pthread_getschedparam(thread.native_handle(), &policy, &sch);
  sch.sched_priority = priority;
  if (pthread_setschedparam(thread.native_handle(), SCHED_FIFO, &sch)) {
    fprintf(stderr, "Failed to setschedparam.\n");
  }
}

static void generate_stream_worker(generate_worker_param *param) {
  const uint32_t block_size = GENERATE_STREAM_WORKER_BLOCK_SIZE;
  unsigned int src_pos = 0;
  unsigned int write_pos = 0;
  unsigned int rp_read_pos = 0;
  const uint32_t rp_cycles = ceil((double)(param->cycles * param->length) / (double)GENERATE_BUFFER_LENGTH);
  volatile int32_t* target_buff = NULL;
  size_t cycle_counter = param->cycles;
  int stop = 0;

  // time interval per block
  setThreadPirority(param->thread, GENERATE_STREAM_WORKER_PRIORITY);
  const double interval = param->step * 1/125e6 * block_size * 1000 / 2;
  const std::chrono::milliseconds intervalPeriodMillis{ (long)(interval)};
  if (param->channel == 0) {
    target_buff = generate_data_chA;
  } else {
    target_buff = generate_data_chB;
  }

  while (!param->force_stop) {
    // prepare fpga
    if (param->channel == 0) {
      generate_cha_cycles(rp_cycles);
      generate_cha_step(param->step);
    } else {
      generate_chb_cycles(rp_cycles);
      generate_chb_step(param->step);
    }
    // copy one full buffer
    generate_copy_to_buff(target_buff, write_pos, param->data, GENERATE_BUFFER_LENGTH);
    write_pos = generate_pos_add(write_pos, GENERATE_BUFFER_LENGTH);
    src_pos += GENERATE_BUFFER_LENGTH;
    // init trigger
    if (param->channel == 0) {
      generate_cha_setup_tigger(param->trigger);
    } else {
      generate_chb_setup_tigger(param->trigger);
    }
    // indicate we are ready
    param->ready = true;
    // define next wakeup
    std::chrono::system_clock::time_point nextStartTime = std::chrono::system_clock::now() + intervalPeriodMillis;
    while (!param->force_stop) {
      // sleep
      std::this_thread::sleep_until(nextStartTime);
      // define next wakeup
      nextStartTime = std::chrono::system_clock::now() + intervalPeriodMillis;
      // read currend rp reader buffer position
      if (param->channel == 0) {
	rp_read_pos = generate_a_read_pos();
      } else {
	rp_read_pos = generate_b_read_pos();
      }
      // number of samples ready to overwrite
      unsigned int diff = generate_pos_sub(rp_read_pos, write_pos);
      if (stop != 0) {
	// stop requested, wait for rp_read_pos arraived end of samples
	if (diff >= block_size) {
	  // lets fill buffer with first value (perpared for next trigger) of data, for the case we miss to stop
	  generate_fill_buff(target_buff, write_pos, param->data[0], block_size);
	  write_pos = generate_pos_add(write_pos, block_size);
	  // decrease stop counter
	  stop -= block_size;
	}
	if (stop <= 0) {
	  // everything was played, lets stop
	  break;
	}
      } else if (diff >= block_size) {
	if (param->length - src_pos > block_size) {
	  // copy full block
	  generate_copy_to_buff(target_buff, write_pos, param->data+src_pos, block_size);
	  src_pos += block_size;
	  write_pos = generate_pos_add(write_pos, block_size);
	} else {
	  // source data end before block_size
	  // samples left in data buffer
	  unsigned int src_left = param->length - src_pos;
	  // copy last samples
	  generate_copy_to_buff(target_buff, write_pos, param->data+src_pos, src_left);
	  src_pos = 0;
	  if (param->cycles) {
	    // no continious play, check for end
	    cycle_counter--;
	    if (cycle_counter <= 0) {
	      // prepare for stop andfill buffer with first data value (perpared for next trigger)
	      generate_fill_buff(target_buff, write_pos, param->data[0], block_size-src_left);
	      // request stop after left samples are read
	      stop = generate_pos_sub(rp_read_pos, generate_pos_add(write_pos, src_left));
	    }
	  }
	  if (!stop) {
	    // if no stop requested copy left data from begin
	    generate_copy_to_buff(target_buff, write_pos, param->data, block_size-src_left);
	    src_pos += block_size - src_left;
	  }
	  // increase write pointer
	  write_pos = generate_pos_add(write_pos, block_size);
	}
	if (src_pos >= param->length) {
	  // data end arraived start from begin
	  src_pos = 0;
	  if (param->cycles) {
	    // no continious play, check for end
	    cycle_counter--;
	    if (cycle_counter <= 0) {
	      // request stop after left samples are read
	      stop = generate_pos_sub(rp_read_pos, write_pos);
	    }
	  }
	}
      }
    }
    // stop DAC
    if (param->channel == 0) {
      generate_cha_stop();
    } else {
      generate_chb_stop();
    }
  }
  param->ready = false;
}

static void generate_stream_start(generate_worker_param &param, const generate_trigger trigger, const uint32_t step, const int16_t *data, const size_t length, const size_t cycles) {
  if (param.running) return;
  if (length < GENERATE_BUFFER_LENGTH) {
    fprintf(stderr, "stream data not long enough!\n");
    return;
  }
  param.trigger = trigger;
  param.step = step;
  param.cycles = cycles;
  param.data = data;
  param.length = length;

  param.force_stop = false;
  param.ready = false;
  param.thread = std::thread(generate_stream_worker, &param);
  param.running = true;
}

static void generate_stream_stop(generate_worker_param &param) {
  if (!param.running) return;
  param.force_stop = true;
  param.thread.join();
  param.running = false;
}

bool generate_stream_cha_is_ready() {
  return worker_cha.ready;
}

bool generate_stream_chb_is_ready() {
  return worker_chb.ready;
}

void generate_stream_cha_start(const generate_trigger trigger, const uint32_t step, const int16_t *data, const size_t length, const size_t cycles) {
  worker_cha.channel = 0;
  generate_stream_start(worker_cha, trigger, step, data, length, cycles);
}

void generate_stream_chb_start(const generate_trigger trigger, const uint32_t step, const int16_t *data, const size_t length, const size_t cycles) {
  worker_chb.channel = 1;
  generate_stream_start(worker_chb, trigger, step, data, length, cycles);
}

void generate_stream_cha_stop() {
  generate_stream_stop(worker_cha);
}

void generate_stream_chb_stop() {
  generate_stream_stop(worker_chb);
}

uint32_t generate_frequency_to_step(const double frequency, const unsigned int length) {
  return round(65536 * frequency / 125e6 * length);
/*
ch_properties->counterStep = (uint32_t) round(65536 * frequency / DAC_FREQUENCY * BUFFER_LENGTH);

sample_freq = frequency * BUFFER_LENGTH
sample_step = 1/frequency/BUFFER_LENGTH = 1/samplefreq

dac_step = 1/DAC_FREQUENCY

counter_step = dac_step/sample_step = dac_step * sample_freq = sample_freq/DAC_FREQUENCY
 = 1/DAC_FREQUENCY * frequency * BUFFER_LENGTH


freq = counter_step * DAC_FREQUENCY / BUFFER_LENGTH
 */
}

uint32_t generate_frequency_to_length(const double frequency, const uint32_t decimation) {
  return round(125e6 / decimation / frequency);
}


int main() {
  cmn_init();
  /*
  osc_init();
  osc_info();
  osc_reset();
  //osc_setup_input_parameters(DE_8192, EQ_LV, EQ_LV, 1, 1);
  osc_setup_input_parameters(DE_1024, EQ_LV, EQ_LV, 1, 1);
  osc_setup_trigger_parameters(2048, 2048, 50, 50, 1250);
  osc_activate_trigger(TR_CH_B_RISING);
  osc_info();
  osc_info();
  osc_info();
  osc_release();
  */
  printf("begin\n");
  generate_init();
  generate_cha_info();


  int16_t dacA_sin[GENERATE_BUFFER_LENGTH*3] = {};
  uint32_t dacA_step = 0;
  synthesis_sin(dacA_sin+0*GENERATE_BUFFER_LENGTH, 4096, -2048, 0);
  synthesis_sin(dacA_sin+1*GENERATE_BUFFER_LENGTH, 4096, 0, 0);
  synthesis_sin(dacA_sin+2*GENERATE_BUFFER_LENGTH, 4096, 2048, 0);
  dacA_step = (uint32_t) round(65536. * 10. / 125e6 * GENERATE_BUFFER_LENGTH);

  printf("default\n");
  generate_default_settings();
  printf("cont\n");
  //generate_cont_cha(G_TR_EXT_RISING, dacA_step, dacA_sin, GENERATE_BUFFER_LENGTH);
  //generate_stream_cha(G_TR_EXT_RISING, dacA_step, dacA_sin, 3*GENERATE_BUFFER_LENGTH);
  generate_stream_cha(G_TR_NOW, dacA_step, dacA_sin, 3*GENERATE_BUFFER_LENGTH);

  printf("end\n");
  generate_cha_info();
  generate_release();
  cmn_release();
  return 0;
}


/*
trigger:

monitor 0x40000018 0 && monitor 0x40000010 1 && monitor 0x40000018 1 && monitor 0x40000018 0 && monitor 0x40000010 0
*/
