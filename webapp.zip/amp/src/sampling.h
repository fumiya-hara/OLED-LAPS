#ifndef SAMPLING_H
#define SAMPLING_H

//const size_t SAMPLING_DECIMATION = 8192;
//#define SAMPLING_DECIMATION_RP RP_DEC_8192
// RP_DEC_1024 (134ms), RP_DEC_64 (8ms), RP_DEC_8 (1ms), RP_DEC_1 (131 us)
const size_t SAMPLING_DECIMATION = 1024;
#define SAMPLING_DECIMATION_RP RP_DEC_1024
//const size_t SAMPLING_DECIMATION = 64;
//#define SAMPLING_DECIMATION_RP RP_DEC_64



const size_t SAMPLING_BUFFER_SIZE = 2 * 16 * 1024; //multiple of Redpitaya buffer

extern size_t samplingBufferWritePos;
extern float samplingBuffer[2][SAMPLING_BUFFER_SIZE];

void samplingStart(const double frequency);
void samplingStop();

#endif
