#include <stdio.h>
#include <chrono>
#include <time.h>
#include <thread>
#include <pthread.h>
#include "redpitaya/rp.h"

#include "sampling.h"

static bool sampling_running = false;
static std::thread samplingThread;

size_t samplingBufferWritePos = 0;
float samplingBuffer[2][SAMPLING_BUFFER_SIZE] = {};


void setThreadPirority() {
  sched_param sch;
  int policy;
  pthread_getschedparam(samplingThread.native_handle(), &policy, &sch);
  sch.sched_priority = 60;
  if (pthread_setschedparam(samplingThread.native_handle(), SCHED_FIFO, &sch)) {
    fprintf(stderr, "Failed to setschedparam.\n");
  }
}

void samplingTask(const double frequency) {
  fprintf(stderr, "sampleThread started\n");
  setThreadPirority();
  const unsigned int BUFFER_SIZE = 16 * 1024;
  const unsigned int BLOCK_SIZE = BUFFER_SIZE / 2;
  unsigned int lastPointer = 0;

  //const double SAMPLE_INTERVAL = 1 / 125e6 * 8192; // adjust to decimatio
  const double SAMPLE_INTERVAL = 1 / 125e6 * SAMPLING_DECIMATION; // adjust to decimatio
  const double interval = SAMPLE_INTERVAL * BLOCK_SIZE * 1000 / 2;
  fprintf(stderr, "sampleThread interval: %f ms\n", interval);
  const std::chrono::milliseconds intervalPeriodMillis{ (long)(interval)};
  std::chrono::system_clock::time_point currentStartTime{ std::chrono::system_clock::now() };
  std::chrono::system_clock::time_point nextStartTime{ currentStartTime };

  clock_t last_clock = clock();

  // Init Redpitaya ACQ
  rp_AcqReset();
  //rp_AcqSetDecimation(RP_DEC_8192); // RP_DEC_1024 (134ms), RP_DEC_64 (8ms), RP_DEC_8 (1ms), RP_DEC_1 (131 us)
  rp_AcqSetDecimation(SAMPLING_DECIMATION_RP); // RP_DEC_1024 (134ms), RP_DEC_64 (8ms), RP_DEC_8 (1ms), RP_DEC_1 (131 us)
  rp_AcqSetTriggerDelay(8*1024);
  rp_AcqStart();

  while (sampling_running) {
    currentStartTime = std::chrono::system_clock::now();
    /*
    clock_t now_clock = clock();
    fprintf(stderr, "sampleThread delay %f \n",
            (double)(now_clock - last_clock) / CLOCKS_PER_SEC*1000);
    last_clock = now_clock;
    */
    // Check Acq pointer posistion
    uint32_t curPos = 0;
    rp_AcqGetWritePointer(&curPos);
    //fprintf(stderr, "UpdateSignal curPos %i \n", curPos);
    if ((curPos - lastPointer) % BUFFER_SIZE >= BLOCK_SIZE) {
      //fprintf(stderr, "rp_AcqGetDataV\n");
      // Read Acq data
      uint32_t size = BLOCK_SIZE;
      int ret = rp_AcqGetDataV(RP_CH_1, lastPointer, &size, samplingBuffer[0] + samplingBufferWritePos);
      //fprintf(stderr, "rp_AcqGetDataV(RP_CH_1) size %u, ret %i\n", size, ret);
      size = BLOCK_SIZE;
      ret = rp_AcqGetDataV(RP_CH_2, lastPointer, &size, samplingBuffer[1] + samplingBufferWritePos);
      //fprintf(stderr, "rp_AcqGetDataV(RP_CH_2) size %u, ret %i\n", size, ret);
      // Increase ring buffer pointer
      samplingBufferWritePos = (samplingBufferWritePos + BLOCK_SIZE) % SAMPLING_BUFFER_SIZE;
      // Increase read pointer
      lastPointer = (lastPointer + BLOCK_SIZE) % BUFFER_SIZE;
    } else {
      //fprintf(stderr, "sampleThread: ignored \n");
    }

    rp_AcqGetWritePointer(&curPos);
    if ((curPos - lastPointer) % BUFFER_SIZE >= BLOCK_SIZE) {
      fprintf(stderr, "sampleThread: timing problems!!\n");
    } else {
      //Sleep till our next period start time
      nextStartTime = currentStartTime + intervalPeriodMillis;
      std::this_thread::sleep_until(nextStartTime);
    }
  }
  rp_AcqStop();
  fprintf(stderr, "sampleThread stoped\n");
}

void samplingStart(const double frequency) {
  sampling_running = true;
  samplingBufferWritePos = 0;
  samplingThread = std::thread(samplingTask, frequency);
}

void samplingStop() {
  fprintf(stderr, "samplingStop\n");
  if (!sampling_running) return;
  fprintf(stderr, "Stopping sampling\n");
  sampling_running = false;
  samplingThread.join();
}

