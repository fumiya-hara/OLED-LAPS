#include <stdio.h>
#include <chrono>
#include <math.h>
#include <time.h>
#include <thread>

#include "sampling.h"
#include "downsample.h"

size_t dsBufferWritePos = 0;
float dsBufferMean[2][DS_BUFFER_SIZE] = {};
float dsBufferSquare[2][DS_BUFFER_SIZE] = {};
unsigned int dsBufferOor[2][DS_BUFFER_SIZE] = {};
float dsBufferI[2][DS_BUFFER_SIZE] = {};
float dsBufferQ[2][DS_BUFFER_SIZE] = {};

static bool downsampling_running = false;
static std::thread dsThread;

const double SAMPLE_INTERVAL = 1.0 / 125e6 * SAMPLING_DECIMATION; // adjust to decimatio

void dsTask(const double frequency, const unsigned int periods) {
  fprintf(stderr, "dsThread started\n");  

  const std::chrono::milliseconds intervalPeriodMillis{ (long)(10)};
  std::chrono::system_clock::time_point currentStartTime{ std::chrono::system_clock::now() };
  std::chrono::system_clock::time_point nextStartTime{ currentStartTime };

  clock_t last_clock = clock();

  const size_t numSamples = dsGetNumSamples(frequency, periods);
  const float  wt_step = 2 * M_PI * SAMPLE_INTERVAL * frequency; //TODO LOT
  fprintf(stderr, "Downsample for Freq %f (%u periods) with %u sample\n", frequency, periods, numSamples);
  unsigned long long turns = 0;
  
  size_t samplingBufferPos = 0;
  size_t lastDownsample = 0;
  double val_mean[2] = {};
  double val_square[2] = {};
  unsigned int val_oor[2] = {};
  double val_I[2] = {};
  double val_Q[2] = {};
  
  while (downsampling_running) {
    currentStartTime = std::chrono::system_clock::now();
    /*
    clock_t now_clock = clock();
    fprintf(stderr, "dsThread delay %f \n",
            (double)(now_clock - last_clock) / CLOCKS_PER_SEC*1000);
    last_clock = now_clock;
    */
    while ((samplingBufferWritePos - samplingBufferPos) % SAMPLING_BUFFER_SIZE > 0) {
      float wt = wt_step * turns;
      float cosine = cos(wt);
      float sine = sin(wt);
      turns++;
      for(unsigned int i=0; i < 2; i++) {
        val_mean[i] += samplingBuffer[i][samplingBufferPos];
        val_square[i] += samplingBuffer[i][samplingBufferPos] * samplingBuffer[0][samplingBufferPos];
        val_oor[i] += abs(samplingBuffer[i][samplingBufferPos]) > 0.99;
        val_I[i] += samplingBuffer[i][samplingBufferPos] * cosine; // real
        val_Q[i] += samplingBuffer[i][samplingBufferPos] * sine; // imag
      }
      //fprintf(stderr, "ds %i, %i, %i\n", samplingBufferWritePos, samplingBufferPos, lastDownsample);
      if ( ((samplingBufferPos - lastDownsample) % SAMPLING_BUFFER_SIZE) >= numSamples) {
        for(unsigned int i=0; i < 2; i++) {
          dsBufferMean[i][dsBufferWritePos] = val_mean[i] / numSamples;
          dsBufferSquare[i][dsBufferWritePos] = val_square[i] / numSamples;
          dsBufferOor[i][dsBufferWritePos] = val_oor[i];
          dsBufferI[i][dsBufferWritePos] = val_I[i] / numSamples;
          dsBufferQ[i][dsBufferWritePos] = val_Q[i] / numSamples;
          val_mean[i] = 0;
          val_square[i] = 0;
          val_oor[i] = 0;
          val_I[i] = 0;
          val_Q[i] = 0;
        }
        dsBufferWritePos = (dsBufferWritePos + 1) % DS_BUFFER_SIZE ;
        lastDownsample = samplingBufferPos;
      }
      samplingBufferPos = (samplingBufferPos + 1) % SAMPLING_BUFFER_SIZE;
    }
    //Sleep till our next period start time
    nextStartTime = currentStartTime + intervalPeriodMillis;
    std::this_thread::sleep_until(nextStartTime);
  }
  fprintf(stderr, "dsThread stoped\n");
}

void dsStart(const double frequency, const unsigned int periods) {
  samplingStart(frequency);
  downsampling_running = true;
  dsBufferWritePos = 0;
  dsThread = std::thread(dsTask, frequency, periods);
}

void dsStop() {
  fprintf(stderr, "dsStop\n");
  if (!downsampling_running) return;
  fprintf(stderr, "Stopping ds\n");
  samplingStop();
  downsampling_running = false;
  dsThread.join();
}

size_t dsGetNumSamples(const double frequency, const unsigned int periods) {
  return 1.0/frequency/SAMPLE_INTERVAL * periods;  //TODO optimiize
}

double dsGetInterval(const double frequency, const unsigned int periods) {
  return dsGetNumSamples(frequency, periods) * SAMPLE_INTERVAL;
}

double dsAlignedFreq(const double frequency) {
  unsigned int samples = round(1.0 / frequency / SAMPLE_INTERVAL);
  return 1.0 / SAMPLE_INTERVAL / samples;
}
