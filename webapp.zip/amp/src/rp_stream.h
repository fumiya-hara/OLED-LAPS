#ifndef RP_STREAM_H
#define RP_STREAM_H

#include <stdint.h>
#include <stddef.h>

/** Success */
#define RP_OK     0
/** Failed to Open EEPROM Device */
#define RP_EOED   1
/** Failed to Open Memory Device */
#define RP_EOMD   2
/** Failed to Close Memory Device*/
#define RP_ECMD   3
/** Failed to Map Memory Device */
#define RP_EMMD   4
/** Failed to Unmap Memory Device */
#define RP_EUMD   5
/** Value Out Of Range */
#define RP_EOOR   6
/** LED Input Direction is not valid */
#define RP_ELID   7
/** Modifying Read Only field */
#define RP_EMRO   8
/** Writing to Input Pin is not valid */
#define RP_EWIP   9
/** Invalid Pin number */
#define RP_EPN    10
/** Uninitialized Input Argument */
#define RP_UIA    11
/** Failed to Find Calibration Parameters */
#define RP_FCA    12
/** Failed to Read Calibration Parameters */
#define RP_RCA    13
/** Buffer too small */
#define RP_BTS    14
/** Invalid parameter value */
#define RP_EIPV   15
/** Unsupported Feature */
#define RP_EUF    16
/** Data not normalized */
#define RP_ENN    17
/** Failed to open bus */
#define RP_EFOB   18
/** Failed to close bus */
#define RP_EFCB   19
/** Failed to acquire bus access */
#define RP_EABA   20
/** Failed to read from the bus */
#define RP_EFRB   21
/** Failed to write to the bus */
#define RP_EFWB   22
/** Extension module not connected */
#define RP_EMNC 23


int cmn_init();
int cmn_release();
int cmn_map(size_t size, size_t offset, void** mapped);
int cmn_unmap(size_t size, void** mapped);

/* data types */
enum equalizer {
	EQ_OFF,
	EQ_LV,
	EQ_HV
};
enum trigger {
	TR_OFF = 0,
	TR_MANUAL,
	TR_CH_A_RISING,
	TR_CH_A_FALLING,
	TR_CH_B_RISING,
	TR_CH_B_FALLING,
	TR_EXT_RISING,
	TR_EXT_FALLING,
	TR_ASG_RISING,
	TR_ASG_FALLING
};
enum decimation {
	DE_OFF          = 0,
	DE_1            = 0x00001,
	DE_8            = 0x00008,
	DE_64           = 0x00040,
	DE_1024         = 0x00400,
	DE_8192         = 0x02000,
	DE_65536        = 0x10000
};

extern const size_t OSC_RAM_A_SIZE;
extern const size_t OSC_RAM_B_SIZE;
extern volatile int32_t *osc_buf_a;
extern volatile int32_t *osc_buf_b;

int osc_init();
int osc_release();
void osc_reset();
void osc_setup_input_parameters(enum decimation dec, enum equalizer ch_a_eq, enum equalizer ch_b_eq, int ch_a_shaping, int ch_b_shaping);
void osc_setup_trigger_parameters(int thresh_a, int thresh_b, int hyst_a, int hyst_b, int deadtime);
void osc_activate_trigger(enum trigger trigger);
unsigned int osc_write_pos();
unsigned int osc_trigger_pos();
unsigned int osc_pos_add(unsigned int a, unsigned int b);
unsigned int osc_pos_sub(unsigned int a, unsigned int b);


#define GENERATE_BUFFER_LENGTH (16 * 1024)
enum generate_trigger {
	G_TR_NOW = 1,
	G_TR_EXT_RISING,
	G_TR_EXT_FALLING,
};
const unsigned int GENERATE_STREAM_WORKER_PRIORITY = 40;
const uint32_t GENERATE_STREAM_WORKER_BLOCK_SIZE = 1024;

int generate_init();
int generate_release();
void generate_default_settings();
void generate_cha_zero();
void generate_chb_zero();
void generate_cha_setup_tigger(const generate_trigger trigger);
void generate_chb_setup_tigger(const generate_trigger trigger);
void generate_cha_step(const uint32_t step);
void generate_chb_step(const uint32_t step);
void generate_cont_cha(const generate_trigger trigger, const uint32_t step, const int16_t *src, const size_t length);
void generate_stream_cha(const generate_trigger trigger, const uint32_t step, const int16_t *src, const size_t length);

void synthesis_sin(int16_t *data_out, const int32_t amplitude, const int32_t offset, const uint32_t delay, const size_t length=GENERATE_BUFFER_LENGTH);
void synthesis_square(int16_t *data_out, const int32_t amplitude, const int32_t offset, const uint32_t delay, const size_t length=GENERATE_BUFFER_LENGTH);
void synthesis_ramp(int16_t *data_out, const int32_t start, const int32_t end, const size_t length);
void synthesis_ramp_sin(int16_t *data_out, const int32_t amplitude, const int32_t start, const int32_t end, const uint32_t periods, const size_t length);

bool generate_stream_cha_is_ready();
bool generate_stream_chb_is_ready();
void generate_stream_cha_start(const generate_trigger trigger, const uint32_t step, const int16_t *data, const size_t length, const size_t cycles=1);
void generate_stream_chb_start(const generate_trigger trigger, const uint32_t step, const int16_t *data, const size_t length, const size_t cycles=1);
void generate_stream_cha_stop();
void generate_stream_chb_stop();
uint32_t generate_frequency_to_step(const double frequency, const unsigned int length=GENERATE_BUFFER_LENGTH);
uint32_t generate_frequency_to_length(const double frequency, const uint32_t decimation);
int osc_info();

#endif
