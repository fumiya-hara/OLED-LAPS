#ifndef DWONSAMPLE_H
#define DWONSAMPLE_H

const size_t DS_BUFFER_SIZE = 1024;

extern size_t dsBufferWritePos;
extern float dsBufferMean[2][DS_BUFFER_SIZE];
extern float dsBufferSquare[2][DS_BUFFER_SIZE];
extern unsigned int dsBufferOor[2][DS_BUFFER_SIZE];
extern float dsBufferI[2][DS_BUFFER_SIZE];
extern float dsBufferQ[2][DS_BUFFER_SIZE];

void dsStart(const double frequency, const unsigned int periods=1);
void dsStop();

size_t dsGetNumSamples(const double frequency, const unsigned int periods=1);
double dsGetInterval(const double frequency, const unsigned int periods=1);
double dsAlignedFreq(const double frequency);

#endif
