(function(APP, $, undefined) {
    
    // App configuration
    APP.config = {};
    APP.config.app_id = 'amp';
    APP.config.app_url = '/bazaar?start=' + APP.config.app_id + '?' + location.search.substr(1);
    APP.config.socket_url = 'ws://' + window.location.hostname + ':9002';

    // WebSocket
    APP.ws = null;

    // Plot
    APP.plot = {};

    // Signal stack
    APP.signalStack = [];

    // Parameters
    APP.processing = false;

    // Starts template application on server
    APP.startApp = function() {

        $.get(APP.config.app_url)
            .done(function(dresult) {
                if (dresult.status == 'OK') {
                    APP.connectWebSocket();
                } else if (dresult.status == 'ERROR') {
                    console.log(dresult.reason ? dresult.reason : "Could not start the application (ERR1)");
                    APP.startApp();
                } else {
                    console.log("Could not start the application (ERR2)");
                    APP.startApp();
                }
            })
            .fail(function() {
                console.log("Could not start the application (ERR3)");
                APP.startApp();
            });
    };




    APP.connectWebSocket = function() {

        //Create WebSocket
        if (window.WebSocket) {
            APP.ws = new WebSocket(APP.config.socket_url);
            APP.ws.binaryType = 'arraybuffer';
        } else if (window.MozWebSocket) {
            APP.ws = new MozWebSocket(APP.config.socket_url);
            APP.ws.binaryType = 'arraybuffer';
        } else {
            console.log("Browser does not support WebSocket");
        }


        // Define WebSocket event listeners
        if (APP.ws) {

            APP.ws.onopen = function() {
                $('#hello_message').text("Hello, Red Pitaya!");
                console.log("Socket opened");

                APP.initParameter();
            };

            APP.ws.onclose = function() {
                console.log("Socket closed");
            };

            APP.ws.onerror = function(ev) {
                $('#hello_message').text("Connection error");
                console.log("Websocket error: ", ev);
            };

            APP.ws.onmessage = function(ev) {
                console.log("Message recieved");


                //Capture signals
                if (APP.processing) {
                    return;
                }
                APP.processing = true;

                try {
                    var data = new Uint8Array(ev.data);
                    var inflate = pako.inflate(data);
                    var text = String.fromCharCode.apply(null, new Uint8Array(inflate));
                    var receive = JSON.parse(text);

                    if (receive.parameters && Object.keys(receive.parameters).length) {
                        APP.onParameters(receive.parameters);
                    }

                    if (receive.signals) {
                        APP.signalStack.push(receive.signals);
                    }
                    APP.processing = false;
                } catch (e) {
                    APP.processing = false;
                    console.log(e);
                } finally {
                    APP.processing = false;
                }



            };
        }
    };


    APP.onParameters  = function(parameters) {
        console.log(parameters);
    }

    APP.sendParameter = function(parameters) {
        APP.ws.send(JSON.stringify({ parameters: parameters }));
    }

    APP.initParameter = function() {
        //console.log($('#parameters').serializeArray());
        var parameters = {};
        $('#parameters').serializeArray().forEach(function(parameter) {
            if (parameter.value === 'on') {
                parameter.value = true;
            }
            parameters[parameter.name] = { value: parameter.value };
        });
        //console.log(parameters);
        APP.sendParameter(parameters);
    };

    APP.updateParameter= function(name, value) {
        var parameters = {};
        parameters[name] = { value: value };
        APP.sendParameter(parameters);
    };
    

    APP.pointArr = [];
    // Processes newly received data for signals
    APP.processSignals = function(new_signals) {

        var pointArr = [];
        var voltage = [];


        // Draw signals
        ['SIGNAL_A', 'SIGNAL_B', 'SIGNAL_C'].forEach(function(sig_name) {
            var points = [];
            if (new_signals[sig_name] && new_signals[sig_name].size > 0) {
                // Ignore empty signals
                for (var i = 0; i < new_signals[sig_name].size; i++) {
                    points.push([i, new_signals[sig_name].value[i]]);
                }
                voltage[sig_name] = new_signals[sig_name].value[new_signals[sig_name].size - 1];
            }
            pointArr.push(points);
        });

        //Update value
        $('#value_a').text(parseFloat(voltage['SIGNAL_A']).toFixed(3));
        $('#value_b').text(parseFloat(voltage['SIGNAL_B']).toFixed(3));
        $('#value_c').text(parseFloat(voltage['SIGNAL_C']).toFixed(3));

        // Update graph
        APP.plot.setData(pointArr);
        APP.plot.resize();
        APP.plot.setupGrid();
        APP.plot.draw();

        APP.pointArr = pointArr;
    };


    APP.exportToCSV = function(array) {
        var csvContent = "data:text/csv;charset=utf-8,";

        for (var i=0; i < 1024; i++) {
            var notfirst = false;
            for (var sig=0; sig < 3; sig++) {
                if (array[sig].length) {
                    if (notfirst) csvContent += '\t';
                    notfirst = true;
                    csvContent += array[sig][i][1];
                }
            }
            csvContent += '\r\n';
        }
        var encodedUri = encodeURI(csvContent);
        var link = document.createElement('a');
        link.setAttribute('href', encodedUri);
        link.setAttribute('download', "amp_data.csv");
        document.body.appendChild(link); // Required for FF
        link.click();
        document.body.removeChild(link);
    }

    //Handler
    APP.signalHandler = function() {
        if (APP.signalStack.length > 0) {
            APP.processSignals(APP.signalStack[0]);
            APP.signalStack.splice(0, 1);
        }
        if (APP.signalStack.length > 2) {
            console.log("Lost signal Stack");
            APP.signalStack = [];
        }
    }
    setInterval(APP.signalHandler, 15);


}(window.APP = window.APP || {}, jQuery));




// Page onload event handler
$(function() {
    //Init plot
    APP.plot = $.plot($('#plotwidget'), [], {
        series: {
            shadowSize: 0, // Drawing is faster without shadows
        },
        yaxis: {
            min: -3,
            max: 3,
        },
        xaxis: {
            min: 0,
            max: 1024,
            show: false
        }
    });

    // Button click func
    $('#read_button').click(function(event) {
        event.preventDefault();
        APP.updateParameter(event.target.name, true);
    });

    // Paramter input change event
    $('#parameters').change(function(event) {
        //event.preventDefault();
        //console.log(event);
        //console.log(event.target.name);
        //console.log(event.target.type);
        //console.log(event.target.value);
        var value = event.target.value;
        if (event.target.type === 'checkbox') {
            value = event.target.checked;
        }
        //console.log(value);
        APP.updateParameter(event.target.name, value);
    });

    $('#export').click(function(event) {
        event.preventDefault();
        APP.exportToCSV(APP.pointArr);
    });

    // Start application
    APP.startApp();
});
