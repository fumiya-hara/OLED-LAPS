#ifndef ACQ_STREAM_H
#define ACQ_STREAM_H

#include <stdint.h>

const size_t ACQ_BUFFER_LENGTH = 16 * 1024;
const double ACQ_DAC_RATE = 125e6;

enum acquire_channel_t { ACQ_CH_A = 1, ACQ_CH_B = 2 };

// init this module (run on start)
bool acquire_init();
// release this module (run on exit)
void acquire_release();
// get buffer of channel
const volatile int32_t *acquire_get_ch_buffer(const acquire_channel_t ch);
// get adc write position in buffer
size_t acquire_write_pos();
// get adc trigger position in buffer
size_t acquire_trigger_pos();
// return (a - b) % ACQ_BUFFER_LENGTH
size_t acquire_pos_sub(const size_t a, const size_t b);
// print ADC register info (debug)
void acquire_info();
// convert 14 bit DAC counts to int16
inline int16_t acquire_to_int16(int32_t value) {
  return ((int16_t)(value << 2) >> 2);
}

#endif
