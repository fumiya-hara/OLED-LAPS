#ifndef SAMPLING_H
#define SAMPLING_H

#include <stdint.h>

#include "redpitaya/rp.h"

// RP_DEC_1024 (134ms), RP_DEC_64 (8ms), RP_DEC_8 (1ms), RP_DEC_1 (131 us)

const size_t SAMPLING_BUFFER_LENGTH = 16 * 1024 * 1024;

extern int16_t sampling_buffer[2][SAMPLING_BUFFER_LENGTH];

void sampling_start(rp_acq_decimation_t decimation = RP_DEC_1024,
                    rp_acq_trig_src_t trigger = RP_TRIG_SRC_NOW);
void sampling_stop();
bool sampling_is_ready();
size_t sampling_write_pos();
size_t sampling_pos_sub(const size_t a, const size_t b);
bool sampling_init();
void sampling_release();

#endif
