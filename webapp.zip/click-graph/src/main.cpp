#include <limits.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/sysinfo.h>
#include <vector>

#include "gen_stream.h"
#include "sampling.h"

#include "main.h"




//Signal size
#define SIGNAL_SIZE_DEFAULT      (20 * 1024)
#define SIGNAL_UPDATE_INTERVAL  5

//Signal
CFloatSignal VOLTAGE("VOLTAGE", SIGNAL_SIZE_DEFAULT, 0.0f);
std::vector<float> g_data(SIGNAL_SIZE_DEFAULT);

//Parameter
CIntParameter GAIN("GAIN", CBaseParameter::RW, 1, 0, 1, 100);
CFloatParameter OFFSET("OFFSET", CBaseParameter::RW, 0.0, 0, 0.0, 5.0);
CBooleanParameter READ_VALUE("READ_VALUE", CBaseParameter::RW, false, 0);
CBooleanParameter CLEAR("CLEAR", CBaseParameter::RW, false, 0);





const char *rp_app_desc(void) {
  return (const char *)"Red Pitaya read voltage.\n";
}

const uint32_t DAC_A_LENGTH = GEN_BUFFER_LENGTH*20;
uint32_t dacA_length = DAC_A_LENGTH;
int16_t dacA_sin[DAC_A_LENGTH] = {};
uint32_t dacA_step = 0;

int rp_app_init(void) {
  fprintf(stderr, "Loading read voltage application\n");

  // Initialization of API
  if (rpApp_Init() != RP_OK) {
    fprintf(stderr, "Red Pitaya API init failed!\n");
    return EXIT_FAILURE;
  }
  else fprintf(stderr, "Red Pitaya API init success!\n");

  //Set signal update interval
  CDataManager::GetInstance()->SetSignalInterval(SIGNAL_UPDATE_INTERVAL);
  //CDataManager::GetInstance()->SetSignalInterval(0);

  sampling_init();
  sampling_start(RP_DEC_8192);
  generate_init();
  //dacA_length = 3*GEN_BUFFER_LENGTH;
  //dacA_length = 2*GEN_BUFFER_LENGTH +3333;
  //synthesis_sin(dacA_sin+0*GEN_BUFFER_LENGTH, 4096, -2048, 0, GEN_BUFFER_LENGTH);
  //synthesis_sin(dacA_sin+1*GEN_BUFFER_LENGTH, 4096, 0, 0, GEN_BUFFER_LENGTH);
  //synthesis_sin(dacA_sin+2*GEN_BUFFER_LENGTH, 4096, 2048, 0, GEN_BUFFER_LENGTH);
  //dacA_step = 86;
  dacA_step = 8;
  //dacA_length = 16*1024;
  dacA_length = SIGNAL_SIZE_DEFAULT;
  //synthesis_ramp(dacA_sin, -8192, 8192, dacA_length);
  //synthesis_ramp_sin(dacA_sin, -8192+1024, 8192-1024, 1024, 60, dacA_length);
  synthesis_ramp_sin(dacA_sin, generate_voltage_to_int(-0.9), generate_voltage_to_int(0.9), generate_voltage_to_int(0.1), 60, dacA_length);
  //dacA_step = generate_frequency_to_step(0.1, dacA_length);
  //dacA_length = generate_frequency_to_length(10, 8192);
  //synthesis_sin(dacA_sin, 4096, 0, 0, dacA_length);
  //dacA_step = generate_frequency_to_step(10, dacA_length);
  //fprintf(stderr, "dac A length %u step %u\n", dacA_length, dacA_step);
  generate_default_settings(GEN_CH_A);
  generate_enable_output(GEN_CH_A);
  generate_setup_step(GEN_CH_A, dacA_step);
  generate_load_data(GEN_CH_A, dacA_sin, GEN_BUFFER_LENGTH);
  generate_setup_tigger(GEN_CH_A, GEN_TR_EXT_RISING);

  
  fprintf(stderr, "init finish\n");
  return 0;
}


int rp_app_exit(void) {
  fprintf(stderr, "Unloading read voltage application\n");
  sampling_release();
  generate_release();
  rpApp_Release();

  return 0;
}


int rp_set_params(rp_app_params_t *p, int len) {
  return 0;
}


int rp_get_params(rp_app_params_t **p) {
  return 0;
}


int rp_get_signals(float ***s, int *sig_num, int *sig_len) {
  return 0;
}






size_t bufferPos = 0;
size_t signalUpdates = 0;

void UpdateSignals(void) {
  size_t block = 8 * 1024;
  while (sampling_pos_sub(sampling_write_pos(), bufferPos) > 0 && block) {
    int16_t ival = sampling_buffer[1][bufferPos];
    float val = ival/8192.0;
    g_data.erase(g_data.begin());
    g_data.push_back(val);
    bufferPos++;
    if (bufferPos >= SAMPLING_BUFFER_LENGTH) {
      bufferPos = 0;
    }
    signalUpdates++;
    block--;
    if (signalUpdates >= SIGNAL_SIZE_DEFAULT) {
      fprintf(stderr, "UpdateSignals stop %i\n", signalUpdates);
      sampling_stop();
      signalUpdates = 0;
      bufferPos = sampling_write_pos();
      break;
    }
  }

  fprintf(stderr, "UpdateSignals end %u %u\n", sampling_write_pos(), signalUpdates);
  // Write data to signal
  for(int i = 0; i < SIGNAL_SIZE_DEFAULT; i++) {
    VOLTAGE[i] = g_data[i] * GAIN.Value() + OFFSET.Value();
  } 
}


void UpdateParams(void){}


void OnNewParams(void) {
  GAIN.Update();
  OFFSET.Update();
  READ_VALUE.Update();
  CLEAR.Update();
  
  if (READ_VALUE.Value() == true) {
    generate_stream_stop(GEN_CH_A);
    sampling_stop();
    signalUpdates = 0;
    bufferPos = 0;
    sampling_start(RP_DEC_8192, RP_TRIG_SRC_AWG_NE);
    //sampling_start(RP_DEC_8192, RP_TRIG_SRC_EXT_PE);
    while (!sampling_is_ready());
    generate_stream_start(GEN_CH_A, GEN_TR_NOW, dacA_step, dacA_sin, dacA_length, 1);
    //generate_stream_start(GEN_CH_A, GEN_TR_EXT_RISING, dacA_step, dacA_sin, dacA_length, 1);
    while (!generate_stream_is_ready(GEN_CH_A));
    rp_DpinSetDirection(RP_DIO0_P, RP_OUT);
    rp_DpinSetState(RP_DIO0_P, RP_LOW);
    rp_DpinSetState(RP_DIO0_P, RP_HIGH);
    rp_DpinSetState(RP_DIO0_P, RP_HIGH);
    rp_DpinSetState(RP_DIO0_P, RP_LOW);
    rp_DpinSetDirection(RP_DIO0_P, RP_IN);

    fprintf(stderr, "Read Button\n");
    //Reset READ value
    READ_VALUE.Set(false);
  }
  if (CLEAR.Value() == true) {
    for(int i = 0; i < SIGNAL_SIZE_DEFAULT; i++) {
      g_data[i] = 0;
    }
    //Reset CLEAR value
    CLEAR.Set(false);
  }
}


void OnNewSignals(void){}


void PostUpdateSignals(void){}
