#ifndef GEN_STREAM_H
#define GEN_STREAM_H

#include <stdint.h>

const size_t GEN_BUFFER_LENGTH = 16 * 1024;
const double GEN_ADC_RATE = 125e6;

enum generate_channel_t { GEN_CH_A = 1, GEN_CH_B = 2 };

enum generate_trigger_t {
  GEN_TR_NOW = 1,
  GEN_TR_EXT_RISING = 2,
  GEN_TR_EXT_FALLING = 3,
  GEN_TR_NOW_ALL,
  GEN_TR_DISABLED,
};

// init this module (run on start)
bool generate_init();
// release this module (run on exit)
void generate_release();
// get buffer of channel
volatile int32_t *generate_get_ch_buffer(const generate_channel_t ch);
// get adc read position in buffer
size_t generate_read_pos(const generate_channel_t ch);
// return (a - b) % GEN_BUFFER_LENGTH
size_t generate_pos_sub(const size_t a, const size_t b);
// print info of DAC register (debuging)
void generate_info(const generate_channel_t ch);
// load default settings
void generate_default_settings(const generate_channel_t ch);
// enable DAC output
void generate_enable_output(const generate_channel_t ch);
// set output to zero
void generate_disable_output(const generate_channel_t ch);
// stop replay (restart with generate_arm(), generate_trigger_sync() or
// generate_setup_tigger())
void generate_disable(const generate_channel_t ch);
// continue disabled DAC
void generate_arm(const generate_channel_t ch);
// set trigger
void generate_setup_tigger(const generate_channel_t ch,
                           const generate_trigger_t trigger);
// set stepcounter
void generate_setup_step(const generate_channel_t ch, const uint32_t step);
// set number of cycles to play (0 = infinite)
void generate_setup_cycles(const generate_channel_t ch, const uint32_t cycles);
// load channel data for length <= GEN_BUFFER_LENGTH
void generate_load_data(const generate_channel_t ch, const int16_t *src,
                        const size_t length);

// calculate stepcounter by decimation
uint32_t generate_decimation_to_step(const uint32_t decimation);
// calculate length by frequency and decimation
size_t generate_frequency_to_length(const double frequency,
                                    const uint32_t decimation);
// calculate frequency by length and decimation
double generate_frequency_by_length(const size_t length,
                                    const uint32_t decimation);
// calculate dac counts from voltage
int16_t generate_voltage_to_int(const double voltage);

// synthesis dc waveform
void synthesis_dc(int16_t *data_out, const int16_t offset, const size_t length);
// synthesis sin waveform (single period)
void synthesis_sin(int16_t *data_out, const int16_t amplitude,
                   const int16_t offset, const size_t delay,
                   const size_t length = GEN_BUFFER_LENGTH);
// synthesis square waveform (single period)
void synthesis_square(int16_t *data_out, const int16_t amplitude,
                      const int16_t offset, const size_t delay,
                      const size_t length = GEN_BUFFER_LENGTH);
// synthesis ramp waveform over whole lenght
void synthesis_ramp(int16_t *data_out, const int16_t start, const int16_t end,
                    const size_t length = GEN_BUFFER_LENGTH);
// synthesis ramp with superimposed sin waveform
void synthesis_ramp_sin(int16_t *data_out, const int16_t start,
                        const int16_t end, const int16_t amplitude,
                        const size_t periods,
                        const size_t length = GEN_BUFFER_LENGTH);

// stream data to DAC output (may start a worker thread)
void generate_stream_start(const generate_channel_t ch,
                           const generate_trigger_t trigger,
                           const uint32_t step, const int16_t *data,
                           const size_t length, const size_t cycles = 0);
// stream data streaming
void generate_stream_stop(const generate_channel_t ch);
// check data streaming is ready for trigger
bool generate_stream_is_ready(const generate_channel_t ch);

#endif
