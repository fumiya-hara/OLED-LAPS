#include <fcntl.h>
#include <pthread.h>
#include <stdio.h>
#include <sys/mman.h>
#include <unistd.h>
#include <thread>

#include "acq_stream.h"
const size_t _OSC_BASE_ADDR = 0x40100000;
const size_t _OSC_BASE_SIZE = 0x00030000;
const size_t _CHA_DATA_OFFSET = 0x10000;
const size_t _CHB_DATA_OFFSET = 0x20000;

struct rp_osc_control_t {
  uint32_t arm : 1;
  uint32_t reset : 1;
  uint32_t trigger_status : 1;
  uint32_t : 29;
  uint32_t trig_source;
  uint32_t cha_thr;
  uint32_t chb_thr;
  uint32_t trigger_delay;
  uint32_t data_dec;
  uint32_t wr_ptr_cur;
  uint32_t wr_ptr_trigger;
  uint32_t cha_hystersis;
  uint32_t chb_hystersis;
  uint32_t other;
  uint32_t pre_trigger_counter;
  uint32_t cha_filt_aa;
  uint32_t cha_filt_bb;
  uint32_t cha_filt_kk;
  uint32_t cha_filt_pp;
  uint32_t chb_filt_aa;
  uint32_t chb_filt_bb;
  uint32_t chb_filt_kk;
  uint32_t chb_filt_pp;
  uint32_t cha_aix_low_addr;
  uint32_t cha_aix_upper_addr;
  uint32_t cha_aix_samples;
  uint32_t cha_aix_enable;
  uint32_t cha_aix_wr_ptr_trigger;
  uint32_t cha_aix_wr_ptr_cur;
  uint32_t _res1;
  uint32_t _res2;
  uint32_t chb_aix_low_addr;
  uint32_t chb_aix_upper_addr;
  uint32_t chb_aix_samples;
  uint32_t chb_aix_enable;
  uint32_t chb_aix_wr_ptr_trigger;
  uint32_t chb_aix_wr_ptr_cur;
  uint32_t _res3;
  uint32_t _res4;
  uint32_t trig_dbc_t;
};

static volatile rp_osc_control_t *_acquire = NULL;
static const volatile int32_t *_data_chA = NULL;
static const volatile int32_t *_data_chB = NULL;
static int _fd_mem;

bool acquire_init() {
  if (!_fd_mem) {
    if ((_fd_mem = open("/dev/mem", O_RDWR | O_SYNC)) == -1) {
      fprintf(stderr, "Failed to open /dev/mem!\n");
      return false;
    }
  }
  if (!_acquire) {
    _acquire = (volatile rp_osc_control_t *)mmap(
        NULL, _OSC_BASE_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, _fd_mem,
        _OSC_BASE_ADDR);
    if (_acquire == (void *)-1) {
      fprintf(stderr, "Failed to map memory!\n");
      return false;
    }
  }
  _data_chA = (int32_t *)((char *)_acquire + _CHA_DATA_OFFSET);
  _data_chB = (int32_t *)((char *)_acquire + _CHB_DATA_OFFSET);
  return true;
}

void acquire_release() {
  if (_acquire) {
    munmap((void *)_acquire, _OSC_BASE_SIZE);
    _acquire = NULL;
  }
  _data_chA = NULL;
  _data_chB = NULL;
  if (_fd_mem) {
    close(_fd_mem);
  }
}

const volatile int32_t *acquire_get_ch_buffer(const acquire_channel_t ch) {
  if (ch == ACQ_CH_A) {
    return _data_chA;
  }
  return _data_chB;
}

size_t acquire_write_pos() { return _acquire->wr_ptr_cur; }

size_t acquire_trigger_pos() { return _acquire->wr_ptr_trigger; }

size_t acquire_pos_sub(const size_t a, const size_t b) {
  return (a - b) % ACQ_BUFFER_LENGTH;
}

void acquire_info() {
  printf(
      "arm %u, reset %u, trigger_status %u, trig_source %u, cha_thr %u, "
      "chb_thr %u, trigger_delay %u, data_dec %u, wr_ptr_cur %u, "
      "wr_ptr_trigger %u, cha_hystersis %u, chb_hystersis %u, other %u, "
      "pre_trigger_counter %u, cha_filt_aa %u, cha_filt_bb %u, cha_filt_kk %u, "
      "cha_filt_pp %u, chb_filt_aa %u, chb_filt_bb %u, chb_filt_kk %u, "
      "chb_filt_pp %u, cha_aix_low_addr %u, cha_aix_upper_addr %u, "
      "cha_aix_samples %u, cha_aix_enable %u, cha_aix_wr_ptr_trigger %u, "
      "cha_aix_wr_ptr_cur %u, chb_aix_low_addr %u, chb_aix_upper_addr %u, "
      "chb_aix_samples %u, chb_aix_enable %u, chb_aix_wr_ptr_trigger %u, "
      "chb_aix_wr_ptr_cur %u, trig_dbc_t %u)\n",
      _acquire->arm, _acquire->reset, _acquire->trigger_status,
      _acquire->trig_source, _acquire->cha_thr, _acquire->chb_thr,
      _acquire->trigger_delay, _acquire->data_dec, _acquire->wr_ptr_cur,
      _acquire->wr_ptr_trigger, _acquire->cha_hystersis,
      _acquire->chb_hystersis, _acquire->other, _acquire->pre_trigger_counter,
      _acquire->cha_filt_aa, _acquire->cha_filt_bb, _acquire->cha_filt_kk,
      _acquire->cha_filt_pp, _acquire->chb_filt_aa, _acquire->chb_filt_bb,
      _acquire->chb_filt_kk, _acquire->chb_filt_pp, _acquire->cha_aix_low_addr,
      _acquire->cha_aix_upper_addr, _acquire->cha_aix_samples,
      _acquire->cha_aix_enable, _acquire->cha_aix_wr_ptr_trigger,
      _acquire->cha_aix_wr_ptr_cur, _acquire->chb_aix_low_addr,
      _acquire->chb_aix_upper_addr, _acquire->chb_aix_samples,
      _acquire->chb_aix_enable, _acquire->chb_aix_wr_ptr_trigger,
      _acquire->chb_aix_wr_ptr_cur, _acquire->trig_dbc_t);
}

/*
int main() {
  acquire_init();
  acquire_info();
  acquire_release();
}
*/
