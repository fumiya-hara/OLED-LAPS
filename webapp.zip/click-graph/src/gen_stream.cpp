#include <fcntl.h>
#include <math.h>
#include <pthread.h>
#include <stdio.h>
#include <sys/mman.h>
#include <unistd.h>
#include <chrono>
#include <thread>

#include "gen_stream.h"
const size_t _GENERATE_BASE_ADDR = 0x40200000;
const size_t _GENERATE_BASE_SIZE = 0x00030000;
const size_t _CHA_DATA_OFFSET = 0x10000;
const size_t _CHB_DATA_OFFSET = 0x20000;

struct rp_ch_properties_t {
  uint32_t amplitudeScale : 14;
  uint32_t : 2;
  uint32_t amplitudeOffset : 14;
  uint32_t : 2;
  uint32_t counterWrap;
  uint32_t startOffset;
  uint32_t counterStep;
  uint32_t : 2;
  uint32_t buffReadPointer : 14;
  uint32_t : 16;
  uint32_t cyclesInOneBurst;
  uint32_t burstRepetitions;
  uint32_t delayBetweenBurstRepetitions;
};

struct rp_generate_control_t {
  uint32_t state;
  rp_ch_properties_t properties_chA;
  rp_ch_properties_t properties_chB;
};

struct rp_generate_state_t {
  uint16_t triggerSelector : 4;
  uint16_t SM_WrapPointer : 1;
  uint32_t : 1;
  uint16_t SM_reset : 1;
  uint16_t setOutputTo0 : 1;
  uint16_t gatedBursts : 1;
  uint16_t : 7;
};

union rp_generate_state_union_t {
  rp_generate_state_t state;
  uint16_t plain;
};

static volatile rp_generate_control_t *_generate = NULL;
static volatile int32_t *_data_chA = NULL;
static volatile int32_t *_data_chB = NULL;
static int _fd_mem;

bool generate_init() {
  if (!_fd_mem) {
    if ((_fd_mem = open("/dev/mem", O_RDWR | O_SYNC)) == -1) {
      fprintf(stderr, "Failed to open /dev/mem!\n");
      return false;
    }
  }
  if (!_generate) {
    _generate = (volatile rp_generate_control_t *)mmap(
        NULL, _GENERATE_BASE_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, _fd_mem,
        _GENERATE_BASE_ADDR);
    if (_generate == (void *)-1) {
      fprintf(stderr, "Failed to map memory!\n");
      return false;
    }
  }
  _data_chA = (int32_t *)((char *)_generate + _CHA_DATA_OFFSET);
  _data_chB = (int32_t *)((char *)_generate + _CHB_DATA_OFFSET);
  return true;
}

void generate_release() {
  generate_stream_stop(GEN_CH_A);
  generate_stream_stop(GEN_CH_B);
  if (_generate) {
    munmap((void *)_generate, _GENERATE_BASE_SIZE);
    _generate = NULL;
  }
  _data_chA = NULL;
  _data_chB = NULL;
  if (_fd_mem) {
    close(_fd_mem);
  }
}

static rp_generate_state_t _get_ch_state(const generate_channel_t ch) {
  rp_generate_state_union_t state;
  if (ch == GEN_CH_A) {
    state.plain = _generate->state & 0xFFFF;
  } else {
    state.plain = _generate->state >> 16;
  }
  return state.state;
}

static void _set_ch_state(const generate_channel_t ch,
                          const rp_generate_state_t new_state) {
  rp_generate_state_union_t state = {.state = new_state};
  uint32_t full_state = _generate->state;
  if (ch == GEN_CH_A) {
    full_state = (full_state & 0xFFFF0000) | state.plain;
  } else {
    full_state = (full_state & 0xFFFF) | (((uint32_t)state.plain) << 16);
  }
  _generate->state = full_state;
}

static volatile rp_ch_properties_t *_get_ch_properties(
    const generate_channel_t ch) {
  if (ch == GEN_CH_A) {
    return &(_generate->properties_chA);
  }
  return &(_generate->properties_chB);
}

volatile int32_t *generate_get_ch_buffer(const generate_channel_t ch) {
  if (ch == GEN_CH_A) {
    return _data_chA;
  }
  return _data_chB;
}

size_t generate_read_pos(const generate_channel_t ch) {
  volatile rp_ch_properties_t *prop = _get_ch_properties(ch);
  return prop->buffReadPointer;
}

size_t generate_pos_sub(const size_t a, const size_t b) {
  return (a - b) % GEN_BUFFER_LENGTH;
}

static void _copy_to_buff(volatile int32_t *target, const unsigned int start,
                          const int16_t *src, const size_t length) {
  // fprintf(stderr, "generate_copy_to_buff start %u, length %u\n", start,
  // length);
  uint32_t write_pos = start;
  for (uint32_t i = 0; i < length; i++) {
    target[write_pos] = src[i];
    write_pos++;
    if (write_pos >= GEN_BUFFER_LENGTH) {
      write_pos = 0;
    }
  }
}

void generate_info(const generate_channel_t ch) {
  rp_generate_state_t state = _get_ch_state(ch);
  volatile rp_ch_properties_t *prop = _get_ch_properties(ch);
  printf(
      "CH %i, triggerSelector %u, SM_WrapPointer %u, SM_reset %u, setOutputTo0 "
      "%u, gatedBursts %u\n",
      ch, state.triggerSelector, state.SM_WrapPointer, state.SM_reset,
      state.setOutputTo0, state.gatedBursts);
  printf(
      "CH %i: amplitudeScale %u, amplitudeOffset %u, counterWrap %u, "
      "startOffset %u, counterStep %u,\n      buffReadPointer %u, "
      "cyclesInOneBurst %u, burstRepetitions %u, delayBetweenBurstRepetitions "
      "%u\n",
      ch, prop->amplitudeScale, prop->amplitudeOffset, prop->counterWrap,
      prop->startOffset, prop->counterStep, prop->buffReadPointer,
      prop->cyclesInOneBurst, prop->burstRepetitions,
      prop->delayBetweenBurstRepetitions);
}

void generate_default_settings(const generate_channel_t ch) {
  volatile rp_ch_properties_t *prop = _get_ch_properties(ch);
  rp_generate_state_t state = {};
  // disable ouput and stop
  state.triggerSelector = 1;
  state.SM_WrapPointer = 1;
  state.SM_reset = 1;
  state.setOutputTo0 = 1;
  state.gatedBursts = 0;
  _set_ch_state(ch, state);
  // no burst
  prop->cyclesInOneBurst = 0;  // Number of repeats of table readout. 0=infinite
  prop->burstRepetitions = 0;
  prop->delayBetweenBurstRepetitions = 0;
  // full_scale
  prop->amplitudeScale = 0x2000;
  prop->amplitudeOffset = 0;
  // whole buffer
  prop->counterWrap = 65536 * GEN_BUFFER_LENGTH - 1;
  prop->startOffset = 0;
}

void generate_enable_output(const generate_channel_t ch) {
  rp_generate_state_t state = _get_ch_state(ch);
  state.setOutputTo0 = 0;
  _set_ch_state(ch, state);
}

void generate_disable_output(const generate_channel_t ch) {
  rp_generate_state_t state = _get_ch_state(ch);
  state.setOutputTo0 = 1;
  _set_ch_state(ch, state);
}

void generate_disable(const generate_channel_t ch) {
  rp_generate_state_t state = _get_ch_state(ch);
  state.SM_reset = 1;
  _set_ch_state(ch, state);
}

void generate_arm(const generate_channel_t ch) {
  rp_generate_state_t state = _get_ch_state(ch);
  state.SM_reset = 0;
  _set_ch_state(ch, state);
}

static void _trigger_sync() {
  rp_generate_state_t state_a = _get_ch_state(GEN_CH_A);
  rp_generate_state_t state_b = _get_ch_state(GEN_CH_B);
  state_a.triggerSelector = 1;  // CH_TR_NOW
  state_a.SM_WrapPointer = 1;
  state_a.SM_reset = 1;
  state_a.gatedBursts = 0;
  _set_ch_state(GEN_CH_A, state_a);
  state_b.triggerSelector = 1;  // CH_TR_NOW
  state_b.SM_WrapPointer = 1;
  state_b.SM_reset = 1;
  state_b.gatedBursts = 0;
  _set_ch_state(GEN_CH_B, state_b);
  // set both SM_reset to 0
  _generate->state &= 0xffbfffbf;
}

void generate_setup_tigger(const generate_channel_t ch,
                           const generate_trigger_t trigger) {
  if (trigger == GEN_TR_NOW_ALL) {
    _trigger_sync();
  } else {
    rp_generate_state_t state = _get_ch_state(ch);
    state.SM_reset = 1;
    _set_ch_state(ch, state);
    if (trigger != GEN_TR_DISABLED) {
      state.triggerSelector = trigger;
      state.SM_WrapPointer = 1;
      state.SM_reset = 0;
      state.gatedBursts = 0;
      _set_ch_state(ch, state);
    }
  }
}

void generate_setup_step(const generate_channel_t ch, const uint32_t step) {
  volatile rp_ch_properties_t *prop = _get_ch_properties(ch);
  prop->counterStep = step;
}

void generate_setup_cycles(const generate_channel_t ch, const uint32_t cycles) {
  volatile rp_ch_properties_t *prop = _get_ch_properties(ch);
  prop->cyclesInOneBurst = cycles;
}

static void _setup_length(const generate_channel_t ch, const uint32_t length) {
  volatile rp_ch_properties_t *prop = _get_ch_properties(ch);
  prop->counterWrap = 65536 * length - 1;
}

void generate_load_data(const generate_channel_t ch, const int16_t *src,
                        const size_t length) {
  if (length > GEN_BUFFER_LENGTH) {
    fprintf(stderr, "stream data too long!\n");
    return;
  }
  _copy_to_buff(generate_get_ch_buffer(ch), 0, src, length);
  _setup_length(ch, length);
}

uint32_t generate_decimation_to_step(const uint32_t decimation) {
  return 65536 / decimation;
}

size_t generate_frequency_to_length(const double frequency,
                                    const uint32_t decimation) {
  return round(GEN_ADC_RATE / decimation / frequency);
}

double generate_frequency_by_length(const size_t length,
                                    const uint32_t decimation) {
  return GEN_ADC_RATE / decimation / length;
}

int16_t generate_voltage_to_int(const double voltage) {
  // TODO: get calibration data
  return voltage * 8191;
}

void synthesis_dc(int16_t *data_out, const int16_t offset,
                  const size_t length) {
  for (int unsigned i = 0; i < length; i++) {
    data_out[i] = offset;
  }
}

void synthesis_sin(int16_t *data_out, const int16_t amplitude,
                   const int16_t offset, const size_t delay,
                   const size_t length) {
  for (int unsigned i = 0; i < length; i++) {
    data_out[i] =
        (int16_t)(amplitude *
                  sin(2.0 * M_PI * (float)i / (float)length + (float)delay)) +
        offset;
  }
}

void synthesis_square(int16_t *data_out, const int16_t amplitude,
                      const int16_t offset, const size_t delay,
                      const size_t length) {
  // Various locally used constants - HW specific parameters
  const int trans = 30;
  // const int trans = 300;

  for (int unsigned i = 0; i < length; i++) {
    unsigned int j = (i + delay) % length;
    if ((0 <= i) && (i < length / 2 - trans)) {
      data_out[j] = offset + amplitude;
    } else if ((i >= length / 2 - trans) && (i < length / 2)) {
      data_out[j] = offset + amplitude -
                    (2 * amplitude / trans) * (i - (length / 2 - trans));
    } else if ((0 <= length / 2) && (i < length - trans)) {
      data_out[j] = offset - amplitude;
    } else if ((i >= length - trans) && (i < length)) {
      data_out[j] =
          offset - amplitude + (2 * amplitude / trans) * (i - (length - trans));
    }
  }
}

void synthesis_ramp(int16_t *data_out, const int16_t start, const int16_t end,
                    const size_t length) {
  for (size_t i = 0; i < length; i++) {
    data_out[i] = (int16_t)(i * (int64_t)(end - start) / length) + start;
  }
}

void synthesis_ramp_sin(int16_t *data_out, const int16_t start,
                        const int16_t end, const int16_t amplitude,
                        const size_t periods, const size_t length) {
  for (int unsigned i = 0; i < length; i++) {
    data_out[i] = (int16_t)(amplitude * sin(2.0 * M_PI * (float)i /
                                            (float)length * (float)periods)) +
                  (int16_t)(i * (int64_t)(end - start) / length) + start;
  }
}

const unsigned int GENERATE_STREAM_WORKER_PRIORITY = 40;

struct worker_param_t {
  bool force_stop = false;
  bool thread_running = false;
  bool ready = false;
  std::thread thread;
  generate_channel_t channel;
  const int16_t *data;
  size_t length;
  size_t cycles;
  generate_trigger_t trigger;
};

static worker_param_t _worker_cha =
    {};  //= {.thread_running=false, .channel=GEN_CH_A};
static worker_param_t _worker_chb =
    {};  //= {.thread_running=false, .channel=GEN_CH_B};

static worker_param_t *_get_worker_param(const generate_channel_t ch) {
  if (ch == GEN_CH_A) {
    return &(_worker_cha);
  }
  return &(_worker_chb);
}

static void _set_thread_pirority(std::thread &thread,
                                 const unsigned int priority) {
  sched_param sch;
  int policy;
  pthread_getschedparam(thread.native_handle(), &policy, &sch);
  sch.sched_priority = priority;
  if (pthread_setschedparam(thread.native_handle(), SCHED_FIFO, &sch)) {
    fprintf(stderr, "Failed to setschedparam.\n");
  }
}

static void _stream_worker(worker_param_t *param) {
  const uint32_t rp_cycles =
      ceil((double)(param->cycles * param->length) / (double)GEN_BUFFER_LENGTH);
  volatile int32_t *target_buff = generate_get_ch_buffer(param->channel);

  fprintf(stderr, "gen_stream worker ch %u thread start\n", param->channel);
  _set_thread_pirority(param->thread, GENERATE_STREAM_WORKER_PRIORITY);
  // prepare fpga
  generate_setup_cycles(param->channel, rp_cycles);
  while (!param->force_stop) {  // restart on triggers if finish
    size_t src_pos = GEN_BUFFER_LENGTH;
    size_t write_pos = 0;
    size_t sample_counter = param->cycles * param->length;
    size_t finish_pos = sample_counter % GEN_BUFFER_LENGTH;
    sample_counter -= GEN_BUFFER_LENGTH;
    fprintf(stderr,
            "gen_stream worker ch %u begin: sample_counter %u, finish_pos %u\n",
            param->channel, sample_counter, finish_pos);
    // indicate we are ready
    param->ready = true;
    while (!param->force_stop && (param->cycles == 0 || sample_counter > 0)) {
      // number of samples ready to overwrite
      size_t diff =
          generate_pos_sub(generate_read_pos(param->channel), write_pos);
      if (diff == 0) {
        std::this_thread::sleep_for(std::chrono::microseconds(50));
        continue;
      }
      if (diff >= GEN_BUFFER_LENGTH / 2) {
        fprintf(stderr, "gen_stream worker ch %u: WARNING diff=%u\n",
                param->channel, diff);
      }
      while (diff > 0) {
        target_buff[write_pos] = param->data[src_pos];
        write_pos++;
        if (write_pos >= GEN_BUFFER_LENGTH) {
          write_pos = 0;
          fprintf(stderr,
                  "gen_stream worker ch %u write DAC buffer loop: "
                  "sample_counter %u, src_pos %u\n",
                  param->channel, sample_counter, src_pos);
        }
        src_pos++;
        if (src_pos >= param->length) {
          src_pos = 0;
        }
        diff--;
        sample_counter--;
        if (sample_counter == 0) {
          fprintf(stderr,
                  "gen_stream worker ch %u data end: write_pos %u, finish_pos "
                  "%u, diff %u\n",
                  param->channel, write_pos, finish_pos, diff);
          // all data written lets fill the rest of the buffer with the first
          // data value
          while (diff > 0 && write_pos < GEN_BUFFER_LENGTH) {
            target_buff[write_pos] = param->data[0];
            write_pos++;
            diff--;
          }
          break;
        }
      }
    }
    param->ready = false;
    // wait until all data was read by DAC
    while (!param->force_stop) {
      // number of samples ready to overwrite
      size_t read_pos = generate_read_pos(param->channel);
      // fill the buffer as much as necessary, to be save
      size_t diff = generate_pos_sub(read_pos, write_pos);
      // fprintf(stderr, "write end: write_pos %u, read_pos %u, diff %u\n",
      //        write_pos, read_pos, diff);
      while (diff > 0 && write_pos < GEN_BUFFER_LENGTH) {
        target_buff[write_pos] = param->data[0];
        write_pos++;
        diff--;
      }
      if (read_pos >= finish_pos && write_pos >= GEN_BUFFER_LENGTH) {
        fprintf(stderr,
                "gen_stream worker ch %u end: finish_pos %u, read_pos %u, "
                "write_pos %u\n",
                param->channel, finish_pos, read_pos, write_pos);
        break;
      }
    }
    // stop DAC
    generate_disable(param->channel);
    if (param->trigger != GEN_TR_EXT_RISING &&
        param->trigger != GEN_TR_EXT_FALLING) {
      break;
    }
    // copy data to DAC for next trigger
    _copy_to_buff(target_buff, 0, param->data, GEN_BUFFER_LENGTH);
    // init trigger
    generate_setup_tigger(param->channel, param->trigger);
  }
  fprintf(stderr, "gen_stream worker ch %u thread end\n", param->channel);
}

void generate_stream_start(const generate_channel_t ch,
                           const generate_trigger_t trigger,
                           const uint32_t step, const int16_t *data,
                           const size_t length, const size_t cycles) {
  worker_param_t *param = _get_worker_param(ch);
  // stop previous stream
  generate_stream_stop(ch);
  // save parameter
  param->channel = ch;
  param->cycles = cycles;
  param->trigger = trigger;
  param->data = data;
  param->length = length;
  param->ready = false;
  param->force_stop = false;
  generate_setup_step(ch, step);
  generate_load_data(ch, data, std::min(length, GEN_BUFFER_LENGTH));
  generate_setup_tigger(ch, trigger);
  if (length <= GEN_BUFFER_LENGTH) {
    generate_setup_cycles(ch, cycles);
    fprintf(stderr, "stream data fits in buffer, no thread needed.\n");
    param->ready = true;
    return;
  }
  // prepare for thread start
  param->thread = std::thread(_stream_worker, param);
  param->thread_running = true;
}

void generate_stream_stop(const generate_channel_t ch) {
  worker_param_t *param = _get_worker_param(ch);
  // disable DAC
  generate_disable(ch);
  param->ready = false;
  if (!param->thread_running) return;
  // stop thread
  param->force_stop = true;
  param->thread.join();
  param->thread_running = false;
}

bool generate_stream_is_ready(const generate_channel_t ch) {
  worker_param_t *param = _get_worker_param(ch);
  return param->ready;
}

/*
int main() {
  generate_init();
  generate_info(GEN_CH_A);
  generate_info(GEN_CH_B);
  generate_release();
}
int main() {
  rp_generate_control_t gen = {};
  rp_generate_state_t state;
  _generate = &gen;

  printf("state 0x%08x\n", _generate->state);
  generate_info(GEN_CH_A);
  generate_info(GEN_CH_B);

  state = _get_ch_state(GEN_CH_A);
  printf("state get A 0x%08x\n", state);
  state.SM_reset = 1;
  printf("state set A 0x%08x\n", state);
  _set_ch_state(GEN_CH_A, state);

  state = _get_ch_state(GEN_CH_B);
  printf("state get B 0x%08x\n", state);
  state.triggerSelector = 3;
  state.setOutputTo0 = 1;
  state.gatedBursts = 1;
  printf("state set B 0x%08x\n", state);
  _set_ch_state(GEN_CH_B, state);

  printf("state 0x%08x\n", _generate->state);
  generate_info(GEN_CH_A);
  generate_info(GEN_CH_B);

  state = _get_ch_state(GEN_CH_A);
  printf("state get A 0x%08x\n", state);
  state.setOutputTo0 = 1;
  _set_ch_state(GEN_CH_A, state);

  state = _get_ch_state(GEN_CH_B);
  printf("state get B 0x%08x\n", state);

  printf("state 0x%08x\n", _generate->state);

  return 0;
}
*/
