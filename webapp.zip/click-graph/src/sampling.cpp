#include <pthread.h>
#include <stdio.h>
#include <chrono>
#include <thread>

#include "acq_stream.h"

#include "sampling.h"

const unsigned int SAMPLING_WORKER_PRIORITY = 60;

static bool _force_stop = false;
static bool _thread_running = false;
static bool _ready = false;
static bool _wait_for_trigger = false;
static std::thread _thread;

static size_t _buffer_write_pos = 0;
int16_t sampling_buffer[2][SAMPLING_BUFFER_LENGTH] = {};

static void _set_thread_pirority(std::thread &thread,
                                 const unsigned int priority) {
  sched_param sch;
  int policy;
  pthread_getschedparam(thread.native_handle(), &policy, &sch);
  sch.sched_priority = priority;
  if (pthread_setschedparam(thread.native_handle(), SCHED_FIFO, &sch)) {
    fprintf(stderr, "Failed to setschedparam.\n");
  }
}

static void _sampling_worker() {
  fprintf(stderr, "_sampling_worker start\n");
  size_t src_read_pos = acquire_write_pos();
  size_t target_write_pos = 0;
  const volatile int32_t *src_buff_a = acquire_get_ch_buffer(ACQ_CH_A);
  const volatile int32_t *src_buff_b = acquire_get_ch_buffer(ACQ_CH_B);
  _set_thread_pirority(_thread, SAMPLING_WORKER_PRIORITY);
  // indicate we are ready
  _ready = true;
  // wait for trigge if requiered
  if (_wait_for_trigger) {
    fprintf(stderr, "_sampling_worker wait for trigger\n");
    rp_acq_trig_state_t trigger_state = RP_TRIG_STATE_WAITING;
    while ((trigger_state == RP_TRIG_STATE_WAITING) && !_force_stop) {
      rp_AcqGetTriggerState(&trigger_state);
      std::this_thread::sleep_for(std::chrono::microseconds(50));
    }
    src_read_pos = acquire_trigger_pos();
  }
  fprintf(stderr, "_sampling_worker enter loop\n");
  while (!_force_stop) {
    // number of samples ready to read
    size_t diff = acquire_pos_sub(acquire_write_pos(), src_read_pos);
    if (diff == 0) {
      // wait on idle
      std::this_thread::sleep_for(std::chrono::microseconds(50));
      continue;
    }
    // copy all avaiable samples
    while (diff > 0) {
      sampling_buffer[0][target_write_pos] =
          acquire_to_int16(src_buff_a[src_read_pos]);
      sampling_buffer[1][target_write_pos] =
          acquire_to_int16(src_buff_b[src_read_pos]);
      src_read_pos++;
      if (src_read_pos >= ACQ_BUFFER_LENGTH) {
        src_read_pos = 0;
      }
      target_write_pos++;
      if (target_write_pos >= SAMPLING_BUFFER_LENGTH) {
        target_write_pos = 0;
      }
      diff--;
      // publish target write pointer
      _buffer_write_pos = target_write_pos;
    }
  }
  rp_AcqStop();
  fprintf(stderr, "_sampling_worker stop\n");
}

void sampling_start(rp_acq_decimation_t decimation, rp_acq_trig_src_t trigger) {
  sampling_stop();
  _force_stop = false;
  _ready = false;
  _buffer_write_pos = 0;
  _wait_for_trigger = true;
  if (trigger == RP_TRIG_SRC_DISABLED || trigger == RP_TRIG_SRC_NOW) {
    _wait_for_trigger = false;
  }
  rp_AcqReset();
  rp_AcqSetDecimation(decimation);
  rp_AcqSetTriggerDelay(8 * 1024);
  rp_AcqSetTriggerSrc(trigger);
  rp_AcqStart();
  _thread = std::thread(_sampling_worker);
  _thread_running = true;
}

void sampling_stop() {
  if (!_thread_running) return;
  _force_stop = true;
  _thread.join();
  _thread_running = false;
}

bool sampling_is_ready() { return _ready; }

size_t sampling_write_pos() { return _buffer_write_pos; }

size_t sampling_pos_sub(const size_t a, const size_t b) {
  return (a - b) % SAMPLING_BUFFER_LENGTH;
}

bool sampling_init() {
  if (rp_Init() != RP_OK) {
    return false;
  }
  if (!acquire_init()) {
    return false;
  }
  return true;
}

void sampling_release() {
  sampling_stop();
  acquire_release();
  rp_Release();
}
